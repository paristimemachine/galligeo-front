// Version générée automatiquement - Ne pas modifier manuellement
// Généré le 2025-09-08T06:35:18.025Z

window.APP_VERSION = {
  "version": "1.0.0",
  "fullVersion": "1.0.0.94",
  "displayVersion": "v1.0.0 (build 94)",
  "shortDisplayVersion": "v1.0.0",
  "detailedVersion": "1.0.0.94+425739d",
  "buildNumber": 94,
  "git": {
    "hash": "425739d",
    "hashFull": "425739dcebf8afcfee088c17f1dbb59573eb4a65",
    "branch": "main",
    "commitCount": 94,
    "lastCommitDate": "2025-09-08T06:35:12.000Z",
    "lastCommitMessage": "add nakala deposit button in Mes cartes, when a map is not tagged as \"Déposé\" + Remove section exemples in \"mes cartes\"",
    "isDirty": false,
    "contributors": [
      "Eric Mermet"
    ]
  },
  "build": {
    "timestamp": "2025-09-08T06:35:18.025Z",
    "environment": "development",
    "buildId": "425739d-1757313318025"
  },
  "project": {
    "name": "galligeo-front",
    "description": "Interface de géoréférencement pour cartes historiques avec intégration Gallica",
    "author": "Paris Time Machine"
  }
};

// Fonction utilitaire pour obtenir les informations de version
window.getAppVersion = function() {
    return window.APP_VERSION;
};

// Fonction pour afficher la version dans la console
window.showVersionInfo = function() {
    const version = window.getAppVersion();
    console.group('📦 Galligeo - Informations de version');
    console.log('Version:', version.displayVersion);
    console.log('Build:', version.buildNumber);
    console.log('Commit:', version.git.hash, '(' + version.git.branch + ')');
    console.log('Date de build:', new Date(version.build.timestamp).toLocaleString('fr-FR'));
    console.log('Dernier commit:', version.git.lastCommitMessage);
    console.log('Contributeurs récents:', version.git.contributors.join(', '));
    console.groupEnd();
};

// Afficher automatiquement les informations de version en mode développement
if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
    console.log('🚀 Galligeo ' + window.APP_VERSION.displayVersion + ' - Mode développement');
    setTimeout(window.showVersionInfo, 1000);
}
