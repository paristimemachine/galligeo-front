// Variables globales pour l'authentification et la gestion des modales
let userData = null;
let isLoggedIn = false;
let authToken = null;
let lastFocusedElement = null; // Pour sauvegarder le focus avant ouverture de modale

// Configuration de l'API d'authentification
const AUTH_API_BASE = 'https://api.ptm.huma-num.fr';

/**
 * Récupère le token JWT depuis l'URL (fragment) ou le localStorage
 */
function getAuthToken() {
    // D'abord, vérifier s'il y a un token dans l'URL (après connexion)
    const hash = window.location.hash;
    if (hash.includes('token=')) {
        const tokenMatch = hash.match(/token=([^&]+)/);
        if (tokenMatch) {
            authToken = tokenMatch[1];
            localStorage.setItem('ptm_auth_token', authToken);
            // Nettoyer l'URL
            window.location.hash = '';
            return authToken;
        }
    }
    
    // Sinon, vérifier le localStorage
    const storedToken = localStorage.getItem('ptm_auth_token');
    if (storedToken) {
        authToken = storedToken;
        return authToken;
    }
    
    return null;
}

/**
 * Vérifie l'état de connexion de l'utilisateur au chargement de la page
 */
async function checkAuthStatus() {
    // Récupérer le token
    const token = getAuthToken();
    
    if (!token) {
        isLoggedIn = false;
        userData = null;
        updateLoginButton();
        document.dispatchEvent(new CustomEvent('userNotLoggedIn'));
        return null;
    }

    try {
        // Utiliser la nouvelle route /auth/api/profile pour récupérer le profil complet
        const profileResponse = await fetch(`${AUTH_API_BASE}/auth/api/profile`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        });

        // Récupérer aussi les données du token JWT pour avoir l'ORCID
        const tokenResponse = await fetch(`${AUTH_API_BASE}/auth/data`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        });

        if (profileResponse.ok && tokenResponse.ok) {
            const profileData = await profileResponse.json();
            const tokenData = await tokenResponse.json();
            
            // Combiner les données du profil et du token
            userData = {
                orcid: tokenData.sub || '',
                name: tokenData.name || `${profileData.first_name || ''} ${profileData.last_name || ''}`.trim(),
                first_name: profileData.first_name || '',
                last_name: profileData.last_name || '',
                email: profileData.email || '',
                institution: profileData.institution || ''
            };
            
            isLoggedIn = true;
            updateLoginButton();
            // Notifier les autres composants que l'utilisateur est connecté
            document.dispatchEvent(new CustomEvent('userLoggedIn', { detail: userData }));
            return userData;
        } else {
            // Token invalide ou expiré
            localStorage.removeItem('ptm_auth_token');
            authToken = null;
            isLoggedIn = false;
            userData = null;
            updateLoginButton();
            // Notifier les autres composants que l'utilisateur n'est pas connecté
            document.dispatchEvent(new CustomEvent('userNotLoggedIn'));
            return null;
        }
    } catch (error) {
        console.error('Erreur lors de la vérification de l\'authentification:', error);
        isLoggedIn = false;
        userData = null;
        updateLoginButton();
        document.dispatchEvent(new CustomEvent('userNotLoggedIn'));
        return null;
    }
}

/**
 * Met à jour l'état des boutons selon l'authentification de l'utilisateur
 */
function updateButtonsForAuth() {
    const btnDeposit = document.getElementById('btn_deposit');
    
    if (isLoggedIn) {
        // Utilisateur connecté : réactiver les boutons selon leurs conditions
        // Pour le bouton de géoréférencement, utiliser la fonction dédiée
        if (typeof setGeoreferencingButtonState === 'function') {
            // Vérifier si count_points est défini et >= 3
            const pointsReady = (typeof count_points !== 'undefined' && count_points >= 3);
            if (pointsReady) {
                setGeoreferencingButtonState('normal', 'Géoréférencer', 'Géoréférencer cette carte');
            } else {
                setGeoreferencingButtonState('disabled', 'Géoréférencer', 'Ajoutez au moins 3 points de contrôle');
            }
        }
        
        if (btnDeposit) {
            btnDeposit.title = 'Déposer le résultat';
        }
    } else {
        // Utilisateur non connecté : désactiver les boutons d'authentification
        if (typeof setGeoreferencingButtonState === 'function') {
            setGeoreferencingButtonState('disabled', 'Géoréférencer', 'Connectez-vous pour utiliser le géoréférencement');
        }
        
        if (btnDeposit) {
            btnDeposit.disabled = true;
            btnDeposit.title = 'Connectez-vous pour déposer des données';
        }
    }
}

/**
 * Met à jour l'affichage du bouton de connexion selon l'état d'authentification
 */
function updateLoginButton() {
    // Chercher le conteneur de boutons de connexion
    let loginContainer = document.querySelector('.fr-header__tools-links ul');
    
    // Si pas trouvé, essayer avec la classe fr-btns-group (pour ggo.html)
    if (!loginContainer) {
        loginContainer = document.querySelector('.fr-btns-group');
    }
    
    // Si toujours pas trouvé, arrêter l'exécution
    if (!loginContainer) {
        console.warn('Conteneur de boutons de connexion non trouvé');
        return;
    }
    
    if (isLoggedIn && userData) {
        // Déterminer le nom à afficher
        const displayName = userData.name || `${userData.first_name || ''} ${userData.last_name || ''}`.trim() || userData.orcid || 'Utilisateur';
        
        // Utilisateur connecté : afficher le menu déroulant
        loginContainer.innerHTML = `
            <li class="fr-nav__item">
                <button class="fr-btn fr-icon-account-line user-menu-toggle" 
                        style="color:#00ac8c;" 
                        data-fr-opened="false" 
                        aria-controls="user-dropdown-menu"
                        onclick="toggleUserMenu()">
                    ${displayName}
                </button>
                <div class="user-dropdown-menu" id="user-dropdown-menu" style="display: none;">
                    <div class="user-info">
                        <p><strong>Nom :</strong> ${userData.last_name || 'Non renseigné'}</p>
                        <p><strong>Prénom :</strong> ${userData.first_name || 'Non renseigné'}</p>
                        <p><strong>ORCID :</strong> ${userData.orcid || 'Non renseigné'}</p>
                        <p><strong>Email :</strong> ${userData.email || 'Non renseigné'}</p>
                        ${userData.institution ? `<p><strong>Institution :</strong> ${userData.institution}</p>` : ''}
                    </div>
                    <hr>
                    <ul class="user-menu-actions">
                        <li>
                            <button data-fr-opened="false" aria-controls="fr-modal-settings" type="button" class="fr-btn fr-btn--sm fr-icon-settings-3-line" data-fr-js-modal-button="true">
                                Paramètres
                            </button>
                        </li>
                        <li>
                            <button onclick="logout()" class="fr-btn fr-btn--sm fr-icon-logout-box-r-line">
                                Se déconnecter
                            </button>
                        </li>
                    </ul>
                </div>
            </li>
        `;
        
        // Ajouter le gestionnaire d'événements pour le bouton Paramètres après création du HTML
        setTimeout(() => {
            const settingsButton = document.querySelector('[aria-controls="fr-modal-settings"]');
            if (settingsButton) {
                // Supprimer l'ancien gestionnaire s'il existe
                settingsButton.removeEventListener('click', handleSettingsButtonClick);
                // Ajouter le nouveau gestionnaire
                settingsButton.addEventListener('click', handleSettingsButtonClick);
            }
        }, 100);
    } else {
        // Utilisateur non connecté : afficher le bouton de connexion standard
        loginContainer.innerHTML = `
            <li>
                <button class="fr-btn fr-icon-lock-line" 
                        href="#" 
                        style="color:#ff5555;"  
                        onclick="redirectToLogin()">
                    Se connecter avec ORCID
                </button>
            </li>
        `;
    }
    
    // Mettre à jour l'état des boutons de fonctionnalité
    updateButtonsForAuth();
}

/**
 * Redirige vers la page de connexion avec l'URL de retour appropriée
 */
function redirectToLogin() {
    const currentUrl = encodeURIComponent(window.location.href);
    window.location.href = `https://api.ptm.huma-num.fr/auth/login?redirect_url=${currentUrl}`;
}

/**
 * Gestionnaire pour le clic sur le bouton Paramètres
 */
function handleSettingsButtonClick(event) {
    event.preventDefault();
    event.stopPropagation();
    
    // Empêcher DSFR de gérer ce clic automatiquement
    const button = event.currentTarget;
    if (button) {
        // Temporairement désactiver le gestionnaire DSFR
        const originalDataAttr = button.getAttribute('data-fr-js-modal-button');
        button.removeAttribute('data-fr-js-modal-button');
        
        // Ouvrir notre modale
        openSettingsModal();
        
        // Restaurer l'attribut après un délai
        setTimeout(() => {
            if (originalDataAttr) {
                button.setAttribute('data-fr-js-modal-button', originalDataAttr);
            }
        }, 100);
    } else {
        // Fallback si pas de bouton
        openSettingsModal();
    }
}

/**
 * Nettoie les styles CSS conflictuels sur la modale
 */
function cleanModalStyles(modal) {
    // Supprimer les styles inline qui peuvent empêcher l'affichage
    modal.style.removeProperty('display');
    modal.style.removeProperty('visibility');
    modal.style.removeProperty('opacity');
    modal.style.removeProperty('position');
    modal.style.removeProperty('top');
    modal.style.removeProperty('left');
    modal.style.removeProperty('width');
    modal.style.removeProperty('height');
    modal.style.removeProperty('background-color');
    modal.style.removeProperty('z-index');
}

/**
 * Ouvre la modale des paramètres utilisateur selon la documentation DSFR
 */
function openSettingsModal() {
    // Sauvegarder l'élément qui a le focus actuellement
    lastFocusedElement = document.activeElement;
    
    // Fermer d'abord le menu utilisateur
    const userMenu = document.getElementById('user-dropdown-menu');
    const userButton = document.querySelector('.user-menu-toggle');
    if (userMenu && userButton) {
        userMenu.style.display = 'none';
        userButton.setAttribute('data-fr-opened', 'false');
    }
    
    // Trouver la modale (maintenant un dialog)
    const modal = document.getElementById('fr-modal-settings');
    if (!modal) {
        console.error('Modale des paramètres non trouvée dans le DOM');
        return;
    }
    
    // Nettoyer les styles CSS conflictuels avant ouverture
    cleanModalStyles(modal);
    
    // Trouver le bouton d'ouverture et mettre à jour data-fr-opened
    const openButton = document.querySelector('[aria-controls="fr-modal-settings"]');
    if (openButton) {
        openButton.setAttribute('data-fr-opened', 'true');
    }
    
    // Utiliser l'API native HTML5 dialog d'abord
    try {
        if (typeof modal.showModal === 'function') {
            modal.showModal();
            
            // Vérifier l'état après ouverture et corriger si nécessaire
            setTimeout(() => {
                // Si la modale est toujours cachée, forcer l'affichage
                if (window.getComputedStyle(modal).display === 'none') {
                    modal.style.display = 'block';
                }
                if (window.getComputedStyle(modal).visibility === 'hidden') {
                    modal.style.visibility = 'visible';
                }
            }, 50);
            
            // Actions post-ouverture
            setTimeout(() => {
                prefillUserProfile();
                initializeTabsInModal();
                
                const firstFocusableElement = modal.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
                if (firstFocusableElement) {
                    firstFocusableElement.focus();
                }
            }, 100);
            
            return;
        }
    } catch (error) {
        console.warn('Erreur avec dialog.showModal():', error);
    }
    
    // Fallback : essayer l'API DSFR si disponible
    if (window.dsfr) {
        try {
            // Méthode recommandée DSFR
            window.dsfr().modal.disclose(modal.id);
            
            // Actions post-ouverture
            setTimeout(() => {
                prefillUserProfile();
                initializeTabsInModal();
                
                const firstFocusableElement = modal.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
                if (firstFocusableElement) {
                    firstFocusableElement.focus();
                }
            }, 100);
            
        } catch (error) {
            console.warn('Échec API DSFR:', error);
            // Fallback manuel
            openModalManually(modal);
        }
    } else {
        console.warn('API DSFR non disponible, ouverture manuelle');
        openModalManually(modal);
    }
}

/**
 * Ouvre la modale manuellement (dialog HTML5)
 */
function openModalManually(modal) {
    // Pour un élément dialog, utiliser showModal() si disponible
    if (typeof modal.showModal === 'function') {
        try {
            modal.showModal();
        } catch (error) {
            console.warn('Erreur showModal():', error);
            // Fallback avec styles CSS
            fallbackDialogOpen(modal);
        }
    } else {
        // Fallback avec styles CSS
        fallbackDialogOpen(modal);
    }
    
    // Actions post-ouverture
    setTimeout(() => {
        prefillUserProfile();
        initializeTabsInModal();
        
        const firstFocusableElement = modal.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
        if (firstFocusableElement) {
            firstFocusableElement.focus();
        }
    }, 100);
}

/**
 * Fallback pour ouvrir la modale avec CSS
 */
function fallbackDialogOpen(modal) {
    modal.removeAttribute('hidden');
    modal.setAttribute('aria-hidden', 'false');
    
    // Ne pas forcer display: flex qui peut entrer en conflit avec DSFR
    // Laisser DSFR ou le CSS natif gérer l'affichage
    modal.style.removeProperty('display');
    modal.style.removeProperty('visibility');
    modal.style.removeProperty('opacity');
    
    modal.classList.add('fr-modal--opened');
}

/**
 * Configure la gestion des clics pour fermer la modale (maintenant géré par DSFR)
 */
function setupModalClickHandler(modal) {
    // Plus besoin de gestionnaire custom, DSFR gère cela nativement
}

/**
 * Initialise la gestion des onglets dans la modale
 */
function initializeTabsInModal() {
    const tabs = document.querySelectorAll('#fr-modal-settings [role="tab"]');
    const panels = document.querySelectorAll('#fr-modal-settings [role="tabpanel"]');

    // Supprimer les anciens listeners pour éviter les doublons
    tabs.forEach(tab => {
        const newTab = tab.cloneNode(true);
        tab.parentNode.replaceChild(newTab, tab);
    });

    // Ajouter les nouveaux listeners
    const newTabs = document.querySelectorAll('#fr-modal-settings [role="tab"]');
    newTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Réinitialiser tous les onglets
            newTabs.forEach(t => {
                t.setAttribute('aria-selected', 'false');
                t.setAttribute('tabindex', '-1');
            });
            
            // Cacher tous les panels
            panels.forEach(p => {
                p.classList.remove('fr-tabs__panel--selected');
                p.hidden = true;
            });
            
            // Activer l'onglet cliqué
            tab.setAttribute('aria-selected', 'true');
            tab.setAttribute('tabindex', '0');
            
            // Afficher le panel correspondant
            const targetPanel = document.getElementById(tab.getAttribute('aria-controls'));
            if (targetPanel) {
                targetPanel.classList.add('fr-tabs__panel--selected');
                targetPanel.hidden = false;
            }
        });
    });
}

/**
 * Prérempli les informations utilisateur dans l'onglet profil
 */
function prefillUserProfile() {
    if (isLoggedIn && userData) {
        const firstNameElement = document.getElementById('user-first-name');
        const lastNameElement = document.getElementById('user-last-name');
        const emailElement = document.getElementById('user-email');
        const orcidElement = document.getElementById('user-orcid');
        const institutionElement = document.getElementById('user-institution');
        
        if (firstNameElement) firstNameElement.textContent = userData.first_name || 'Non renseigné';
        if (lastNameElement) lastNameElement.textContent = userData.last_name || 'Non renseigné';
        if (emailElement) emailElement.textContent = userData.email || 'Non renseigné';
        if (orcidElement) orcidElement.textContent = userData.orcid || 'Non renseigné';
        if (institutionElement) institutionElement.textContent = userData.institution || 'Non renseigné';
    } else {
        // Afficher des valeurs par défaut si pas connecté
        const elements = [
            { id: 'user-first-name', text: 'Non disponible' },
            { id: 'user-last-name', text: 'Non disponible' },
            { id: 'user-email', text: 'Non disponible' },
            { id: 'user-orcid', text: 'Non disponible' },
            { id: 'user-institution', text: 'Non disponible' }
        ];
        
        elements.forEach(item => {
            const element = document.getElementById(item.id);
            if (element) element.textContent = item.text;
        });
    }
}

/**
 * Ferme la modale des paramètres selon la documentation DSFR
 */
function closeSettingsModal() {
    const modal = document.getElementById('fr-modal-settings');
    if (!modal) {
        console.error('Modale non trouvée pour fermeture');
        return;
    }
    
    // Mettre à jour le bouton d'ouverture
    const openButton = document.querySelector('[aria-controls="fr-modal-settings"]');
    if (openButton) {
        openButton.setAttribute('data-fr-opened', 'false');
    }
    
    // Essayer d'abord l'API native dialog
    try {
        if (typeof modal.close === 'function' && modal.open) {
            modal.close();
            
            // Restaurer le focus
            setTimeout(() => {
                if (lastFocusedElement && lastFocusedElement !== document.body) {
                    try {
                        lastFocusedElement.focus();
                    } catch (e) {
                        console.warn('Impossible de restaurer le focus:', e);
                        document.body.focus();
                        document.body.blur();
                    }
                }
                lastFocusedElement = null;
            }, 50);
            
            return;
        }
    } catch (error) {
        console.warn('Erreur avec dialog.close():', error);
    }
    
    // Fallback : API DSFR
    if (window.dsfr) {
        try {
            window.dsfr().modal.conceal(modal.id);
            
            // Restaurer le focus
            setTimeout(() => {
                if (lastFocusedElement && lastFocusedElement !== document.body) {
                    try {
                        lastFocusedElement.focus();
                    } catch (e) {
                        console.warn('Impossible de restaurer le focus:', e);
                        document.body.focus();
                        document.body.blur();
                    }
                }
                lastFocusedElement = null;
            }, 50);
            
        } catch (error) {
            console.error('Erreur lors de la fermeture avec DSFR:', error);
            closeModalManually(modal);
        }
    } else {
        console.warn('API DSFR non disponible, fermeture manuelle');
        closeModalManually(modal);
    }
}

/**
 * Ferme la modale manuellement (dialog HTML5)
 */
function closeModalManually(modal) {
    // Pour un élément dialog, utiliser close() si disponible
    if (typeof modal.close === 'function' && modal.open) {
        try {
            modal.close();
        } catch (error) {
            console.warn('Erreur close():', error);
            // Fallback avec styles CSS
            fallbackDialogClose(modal);
        }
    } else {
        // Fallback avec styles CSS
        fallbackDialogClose(modal);
    }
    
    // Restaurer le focus
    setTimeout(() => {
        if (lastFocusedElement && lastFocusedElement !== document.body) {
            try {
                lastFocusedElement.focus();
            } catch (e) {
                document.body.focus();
                document.body.blur();
            }
        }
        lastFocusedElement = null;
    }, 50);
}

/**
 * Fallback pour fermer la modale avec CSS
 */
function fallbackDialogClose(modal) {
    modal.setAttribute('aria-hidden', 'true');
    modal.setAttribute('hidden', '');
    modal.style.display = 'none';
    modal.classList.remove('fr-modal--opened');
}

/**
 * Prérempli les champs de la modale des paramètres
 */
function prefillUserFields() {
    if (isLoggedIn && userData) {
        // Diviser le nom complet en prénom et nom
        const fullName = userData.name || '';
        const nameParts = fullName.split(' ');
        const familyName = nameParts.length > 0 ? nameParts[nameParts.length - 1] : '';
        const givenName = nameParts.length > 1 ? nameParts.slice(0, -1).join(' ') : '';
        
        // Préremplir les champs s'ils existent et sont vides
        const familyNameField = document.getElementById('input-family-name-1');
        const givenNameField = document.getElementById('input-firstname-1');
        const institutionField = document.getElementById('input-institution');
        
        if (familyNameField && !familyNameField.value && familyName) {
            familyNameField.value = familyName;
        }
        
        if (givenNameField && !givenNameField.value && givenName) {
            givenNameField.value = givenName;
        }
        
        if (institutionField && !institutionField.value && userData.institution) {
            institutionField.value = userData.institution;
        }
    }
}

/**
 * Sauvegarde les paramètres utilisateur
 */
async function saveUserSettings() {
    try {
        const firstNameField = document.getElementById('settings-firstname');
        const lastNameField = document.getElementById('settings-lastname');
        const emailField = document.getElementById('settings-email');
        const institutionField = document.getElementById('settings-institution');
        
        const updatedData = {
            first_name: firstNameField?.value || '',
            last_name: lastNameField?.value || '',
            email: emailField?.value || '',
            institution: institutionField?.value || ''
        };
        
        // Appeler l'API pour sauvegarder les données
        const response = await authenticatedFetch(`${AUTH_API_BASE}/auth/api/profile`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(updatedData)
        });
        
        if (response.ok) {
            // Mettre à jour les données locales
            userData = { ...userData, ...updatedData };
            
            // Mettre à jour l'affichage
            updateLoginButton();
            
            // Fermer la modale
            closeSettingsModal();
            
            // Afficher un message de succès (vous pouvez adapter selon votre système de notifications)
            console.log('Paramètres sauvegardés avec succès');
            
        } else {
            throw new Error('Erreur lors de la sauvegarde');
        }
        
    } catch (error) {
        console.error('Erreur lors de la sauvegarde des paramètres:', error);
        // Afficher un message d'erreur (vous pouvez adapter selon votre système de notifications)
        alert('Erreur lors de la sauvegarde des paramètres');
    }
}

/**
 * Bascule l'affichage du menu utilisateur
 */
function toggleUserMenu() {
    const menu = document.getElementById('user-dropdown-menu');
    const button = document.querySelector('.user-menu-toggle');
    
    if (menu.style.display === 'none') {
        menu.style.display = 'block';
        menu.style.zIndex = '99999';
        menu.style.position = 'absolute';
        button.setAttribute('data-fr-opened', 'true');
    } else {
        menu.style.display = 'none';
        button.setAttribute('data-fr-opened', 'false');
    }
}

/**
 * Ferme le menu utilisateur si on clique ailleurs
 */
document.addEventListener('click', function(event) {
    const menu = document.getElementById('user-dropdown-menu');
    const button = document.querySelector('.user-menu-toggle');
    
    if (menu && button && !button.contains(event.target) && !menu.contains(event.target)) {
        menu.style.display = 'none';
        button.setAttribute('data-fr-opened', 'false');
    }
});

/**
 * Déconnecte l'utilisateur
 */
async function logout() {
    try {
        // Supprimer le token du localStorage
        localStorage.removeItem('ptm_auth_token');
        authToken = null;
        
        // Réinitialiser les variables locales
        userData = null;
        isLoggedIn = false;
        
        // Mettre à jour l'interface
        updateLoginButton(); // Cela appellera aussi updateButtonsForAuth()
        
        // Notifier les autres composants de la déconnexion
        document.dispatchEvent(new CustomEvent('userLoggedOut'));
        
        // Optionnel : rediriger vers la page d'accueil ou rafraîchir la page
        // window.location.reload();
        
    } catch (error) {
        console.error('Erreur lors de la déconnexion:', error);
    }
}

/**
 * Prérempli les champs utilisateur dans les formulaires
 */
function prefillUserFields() {
    if (isLoggedIn && userData) {
        // Diviser le nom complet en prénom et nom
        const fullName = userData.name || '';
        const nameParts = fullName.split(' ');
        const familyName = nameParts.length > 0 ? nameParts[nameParts.length - 1] : '';
        const givenName = nameParts.length > 1 ? nameParts.slice(0, -1).join(' ') : '';
        
        // Préremplir les champs s'ils existent et sont vides
        const familyNameField = document.getElementById('input-family-name-1');
        const givenNameField = document.getElementById('input-firstname-1');
        const institutionField = document.getElementById('input-institution');
        
        if (familyNameField && !familyNameField.value && familyName) {
            familyNameField.value = familyName;
        }
        
        if (givenNameField && !givenNameField.value && givenName) {
            givenNameField.value = givenName;
        }
        
        if (institutionField && !institutionField.value && userData.institution) {
            institutionField.value = userData.institution;
        }
    }
}

/**
 * Effectue un appel API authentifié
 */
async function authenticatedFetch(url, options = {}) {
    const token = getAuthToken();
    if (!token) {
        throw new Error('Utilisateur non authentifié');
    }
    
    const headers = {
        'Accept': 'application/json',
        'Authorization': `Bearer ${token}`,
        ...options.headers
    };
    
    return fetch(url, {
        ...options,
        headers
    });
}

/**
 * Sauvegarde des données utilisateur spécifiques à l'application Galligeo
 */
async function saveGalligeoUserData(data) {
    try {
        const response = await authenticatedFetch(`${AUTH_API_BASE}/auth/app/galligeo/data`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            return await response.json();
        } else {
            throw new Error('Erreur lors de la sauvegarde');
        }
    } catch (error) {
        console.error('Erreur lors de la sauvegarde des données Galligeo:', error);
        throw error;
    }
}

/**
 * Récupère les données utilisateur spécifiques à l'application Galligeo
 */
async function getGalligeoUserData() {
    try {
        const response = await authenticatedFetch(`${AUTH_API_BASE}/auth/app/galligeo/data`);
        
        if (response.ok) {
            return await response.json();
        } else {
            throw new Error('Erreur lors de la récupération des données');
        }
    } catch (error) {
        console.error('Erreur lors de la récupération des données Galligeo:', error);
        throw error;
    }
}

// Ajout d'un écouteur d'événement pour préremplir les champs quand la modale s'ouvre
document.addEventListener('DOMContentLoaded', function() {
    // Écouter les événements de connexion/déconnexion pour mettre à jour les boutons
    document.addEventListener('userLoggedIn', function(event) {
        console.log('Utilisateur connecté - mise à jour des boutons');
        updateButtonsForAuth();
    });
    
    document.addEventListener('userLoggedOut', function() {
        console.log('Utilisateur déconnecté - mise à jour des boutons');
        updateButtonsForAuth();
    });
    
    document.addEventListener('userNotLoggedIn', function() {
        console.log('Utilisateur non connecté - mise à jour des boutons');
        updateButtonsForAuth();
    });

    // Initialiser l'état des boutons au chargement
    setTimeout(updateButtonsForAuth, 500); // Délai pour s'assurer que les variables sont initialisées

    // Initialiser la modale des paramètres avec les bons attributs
    const settingsModal = document.getElementById('fr-modal-settings');
    if (settingsModal) {
        // Pour un dialog DSFR, ne pas forcer les styles CSS - laisser DSFR gérer
        // Seulement s'assurer que la modale n'est pas ouverte au démarrage
        if (settingsModal.open) {
            settingsModal.close();
        }
        
        // Vérifier que l'API DSFR est disponible
        if (window.dsfr) {
            // Essayer d'initialiser la modale avec DSFR
            try {
                window.dsfr().modal.refreshModal(settingsModal.id);
            } catch (error) {
                console.warn('Impossible d\'initialiser la modale DSFR:', error);
            }
        } else {
            // Attendre que DSFR soit chargé
            let attempts = 0;
            const checkDSFR = setInterval(() => {
                attempts++;
                if (window.dsfr) {
                    try {
                        window.dsfr().modal.refreshModal(settingsModal.id);
                    } catch (error) {
                        console.warn('Impossible d\'initialiser la modale DSFR en différé:', error);
                    }
                    clearInterval(checkDSFR);
                } else if (attempts > 20) { // Arrêter après 2 secondes
                    clearInterval(checkDSFR);
                }
            }, 100);
        }
    }
    
    // Observer les changements du DOM pour détecter l'ouverture de la modale de dépôt
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.type === 'attributes' && mutation.attributeName === 'style') {
                const modal = document.getElementById('fr-modal-deposit');
                if (modal && modal.style.display !== 'none' && isLoggedIn) {
                    // La modale est ouverte, préremplir les champs
                    setTimeout(prefillUserFields, 100); // Petit délai pour s'assurer que les champs sont présents
                }
            }
        });
    });
    
    // Observer la modale de dépôt
    const modal = document.getElementById('fr-modal-deposit');
    if (modal) {
        observer.observe(modal, { attributes: true, attributeFilter: ['style'] });
    }
    
    // Configuration des gestionnaires pour la modale des paramètres DSFR
    if (settingsModal) {
        // Variable pour éviter les événements en double
        let isModalOpening = false;
        
        // Gestionnaire pour le bouton de fermeture
        const closeButton = settingsModal.querySelector('.fr-link--close');
        if (closeButton) {
            closeButton.addEventListener('click', function(event) {
                event.preventDefault();
                closeSettingsModal();
            });
        }
        
        // Gestionnaire pour fermer en cliquant en dehors (pour dialog)
        settingsModal.addEventListener('click', function(event) {
            if (event.target === settingsModal) {
                closeSettingsModal();
            }
        });
        
        // Écouter les événements DSFR pour la modale seulement si elle se ferme vraiment
        settingsModal.addEventListener('dsfr.conceal', function(event) {
            // Ignorer l'événement si on est en train d'ouvrir la modale
            if (isModalOpening) {
                return;
            }
            
            // Mettre à jour le bouton d'ouverture
            const openButton = document.querySelector('[aria-controls="fr-modal-settings"]');
            if (openButton) {
                openButton.setAttribute('data-fr-opened', 'false');
            }
            
            // Restaurer le focus si la fermeture n'a pas été gérée par closeSettingsModal
            setTimeout(() => {
                if (lastFocusedElement && lastFocusedElement !== document.body) {
                    try {
                        lastFocusedElement.focus();
                    } catch (e) {
                        console.warn('Impossible de restaurer le focus (événement DSFR):', e);
                        document.body.focus();
                        document.body.blur();
                    }
                }
                lastFocusedElement = null;
            }, 50);
        });
        
        // Écouter l'événement d'ouverture pour éviter les conflits
        settingsModal.addEventListener('dsfr.disclose', function(event) {
            isModalOpening = true;
            
            // Mettre à jour le bouton d'ouverture
            const openButton = document.querySelector('[aria-controls="fr-modal-settings"]');
            if (openButton) {
                openButton.setAttribute('data-fr-opened', 'true');
            }
            
            // Réinitialiser le flag après un délai
            setTimeout(() => {
                isModalOpening = false;
            }, 200);
        });
    }
});

/**
 * Gestionnaire global pour les événements clavier (notamment Échap pour fermer les modales)
 */
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        // Fermer la modale des paramètres si elle est ouverte
        const settingsModal = document.getElementById('fr-modal-settings');
        if (settingsModal && settingsModal.getAttribute('aria-hidden') === 'false') {
            closeSettingsModal();
            event.preventDefault();
            return;
        }
        
        // Fermer le menu utilisateur si il est ouvert
        const userMenu = document.getElementById('user-dropdown-menu');
        const userButton = document.querySelector('.user-menu-toggle');
        if (userMenu && userMenu.style.display !== 'none') {
            userMenu.style.display = 'none';
            if (userButton) {
                userButton.setAttribute('data-fr-opened', 'false');
            }
            event.preventDefault();
        }
    }
});



// Exposer les fonctions globalement pour le debug
window.checkAuthStatus = checkAuthStatus;
window.logout = logout;
window.openSettingsModal = openSettingsModal;
window.closeSettingsModal = closeSettingsModal;// function geoserverApi(endpoint) {
//     fetch("http://holtanna:8080/geoserver/rest/workspaces/generic/datastores/holtanna/featuretypes.json")
//   .then((response) => response.json())
//   .then((data) => console.log(data));
// }

urlGeoserverApi = 'http://holtanna.ut-capitole.fr/geoserver/rest/workspaces/generic/datastores/holtanna/featuretypes.json';



function getDataFromApi() {

    fetch(urlGeoserverApi, {
      method: 'GET',
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': 'Basic ' + btoa('admin' + ":" + '=y88AQ.u'),
        'redirect': 'follow'
      },
  })
  .then(response => response.json())
  // .then(response => console.log(JSON.stringify(response)))
  //.then(response => addJsonLayerSteriles(response))
  
  // addJsonLayerSteriles(response.json());
  
  }

// Exposer les fonctions principales globalement
window.checkAuthStatus = checkAuthStatus;
window.logout = logout;
window.openSettingsModal = openSettingsModal;
window.closeSettingsModal = closeSettingsModal;
  