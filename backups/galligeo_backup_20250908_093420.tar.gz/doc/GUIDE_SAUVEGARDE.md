# 💾 Sauvegarde Temporaire des Points de Contrôle - Guide d'Utilisation

## 🎯 Vue d'ensemble

Cette fonctionnalité permet de **sauvegarder automatiquement vos points de contrôle** directement dans votre navigateur, garantissant qu'aucun travail ne sera perdu en cas de :
- Fermeture accidentelle de l'onglet
- Rafraîchissement de la page  
- Perte de connexion internet
- Problème technique

## ✨ Fonctionnalités Principales

### 🔄 Sauvegarde Automatique
- **Sauvegarde toutes les 30 secondes** (configurable)
- **Sauvegarde lors de modifications** des points de contrôle
- **Sauvegarde de sécurité** à la fermeture de page
- **Aucune action requise** de votre part

### 💾 Boutons Manuels
Dans la barre latérale, vous trouverez :
- **💾 Sauver** : Sauvegarde manuelle immédiate
- **📁 Restaurer** : Interface pour récupérer des sauvegardes

### 📊 Indicateurs Visuels
- **Statut en temps réel** : "💾 Sauvegardé 14:30:25"
- **Notifications** lors des opérations
- **État des boutons** selon le contexte

## 🚀 Première Utilisation

### 1. Démarrage Automatique
- La sauvegarde automatique s'active dès le chargement de la page
- Aucune configuration requise pour un usage basique

### 2. Si vous avez des sauvegardes existantes
- Au chargement, l'application proposera automatiquement de restaurer une sauvegarde récente
- Vous pouvez accepter ou refuser

### 3. Pendant votre travail
- Saisissez vos points de contrôle normalement
- La sauvegarde se fait automatiquement en arrière-plan
- Vous pouvez voir l'indicateur de sauvegarde dans la barre latérale

## 📁 Restaurer des Points de Contrôle

### Restauration Automatique
1. Rechargez la page ou rouvrez l'application
2. Si une sauvegarde récente existe, un dialogue apparaît
3. Cliquez "OK" pour restaurer ou "Annuler" pour ignorer

### Restauration Manuelle
1. Cliquez sur le bouton **📁 Restaurer**
2. Une modale s'ouvre avec la liste des sauvegardes
3. Choisissez la sauvegarde désirée
4. Cliquez "Restaurer"
5. Vos points apparaissent automatiquement sur les cartes

### Informations des Sauvegardes
Chaque sauvegarde affiche :
- **Date et heure** de création
- **Nombre de points** de contrôle
- **Emprise** (si définie)
- **ARK associée** (carte Gallica)
- **Type de déclencheur** (automatique, manuel, etc.)

## ⚙️ Configuration Avancée

### Accès aux Paramètres
1. Ouvrez **Mon Galligeo** (icône utilisateur)
2. Allez dans l'onglet **"Paramètres géoréférencement"**
3. Descendez à la section **"Sauvegarde automatique"**

### Paramètres Disponibles
- ✅ **Activer la sauvegarde automatique** (recommandé : activé)
- 🕒 **Fréquence de sauvegarde** : 15s, 30s, 1min, 5min (recommandé : 30s)
- 📊 **Nombre max de sauvegardes** : 1 à 50 (recommandé : 10)

### Recommandations
- **Fréquence 30 secondes** : Bon équilibre sécurité/performance
- **10 sauvegardes maximum** : Évite l'encombrement
- **Toujours laisser activé** sauf contraintes spécifiques

## 🛠️ Gestion des Sauvegardes

### Consulter les Sauvegardes
1. Cliquez sur **📁 Restaurer**
2. Parcourez la liste chronologique
3. Chaque sauvegarde est datée et décrite

### Supprimer des Sauvegardes
1. Dans la modale de restauration
2. Bouton **"Supprimer toutes les sauvegardes"** en bas
3. Confirmation requise

### Stockage Local
- Les sauvegardes sont stockées dans votre navigateur
- **Pas de synchronisation entre appareils**
- **Effacement possible** lors du nettoyage du navigateur

## 🔍 Dépannage

### La sauvegarde ne fonctionne pas
1. **Vérifiez que JavaScript est activé**
2. **Regardez la console du navigateur** (F12)
3. **Vérifiez l'espace de stockage** du navigateur

### Impossible de restaurer
1. **Vérifiez qu'il y a des sauvegardes** (bouton 📁 activé)
2. **Essayez de recharger la page**
3. **Consultez la console** pour les erreurs

### Sauvegardes manquantes
1. **Vérifiez que vous êtes sur le même navigateur/appareil**
2. **Vérifiez que le localStorage n'a pas été vidé**
3. **Les sauvegardes sont locales** (pas de synchronisation cloud)

### Messages d'erreur fréquents
- **"Quota dépassé"** : Videz les anciennes sauvegardes
- **"Données corrompues"** : Supprimez toutes les sauvegardes
- **"Fonction non disponible"** : Rechargez la page

## 🔐 Sécurité et Confidentialité

### Stockage des Données
- **Stockage 100% local** dans votre navigateur
- **Aucune transmission** vers des serveurs externes
- **Contrôle total** sur vos données

### Que Contiennent les Sauvegardes
- Coordonnées des points de contrôle
- Polygones d'emprise
- Paramètres de géoréférencement
- Métadonnées (heure, session, ARK)
- **Pas d'informations personnelles**

### Suppression des Données
- **Nettoyage du navigateur** supprime les sauvegardes
- **Bouton de suppression** dans l'interface
- **Pas de récupération possible** après suppression

## 📊 Scénarios d'Usage

### Scénario 1 : Travail Normal
```
1. Charger une carte Gallica
2. Placer des points de contrôle
3. → Sauvegarde automatique toutes les 30s
4. Continuer le travail en sécurité
5. Géoréférencer quand prêt
```

### Scénario 2 : Interruption Imprévue
```
1. Travail en cours sur des points
2. → Fermeture accidentelle du navigateur
3. Relancer l'application
4. → Proposition de restauration automatique
5. Accepter la restauration
6. → Reprendre là où vous vous êtes arrêté
```

### Scénario 3 : Mode Déconnecté
```
1. Perte de connexion internet
2. → Sauvegarde locale continue de fonctionner
3. Continuer à travailler normalement
4. Reconnexion réseau
5. → Aucune perte de données
```

### Scénario 4 : Travail Collaboratif
```
1. Plusieurs personnes sur le même ordinateur
2. → Chaque session a ses propres sauvegardes
3. Changement d'utilisateur
4. → Chacun peut restaurer ses propres points
```

## 🔮 Limitations Actuelles

### Stockage
- **Limite du localStorage** du navigateur (~5-10 MB)
- **Pas de synchronisation** entre appareils/navigateurs
- **Suppression possible** lors du nettoyage automatique

### Fonctionnalités
- **Pas d'historique détaillé** des modifications
- **Pas de commentaires** sur les sauvegardes
- **Pas de partage** direct entre utilisateurs

### Techniques
- **Nécessite JavaScript activé**
- **Fonctionne sur navigateurs modernes** uniquement
- **Performances** dépendantes de la taille des données

## 💡 Conseils et Bonnes Pratiques

### Utilisation Optimale
1. **Laissez la sauvegarde automatique activée**
2. **Sauvegardez manuellement** avant les pauses
3. **Vérifiez périodiquement** les sauvegardes disponibles
4. **Nettoyez** les anciennes sauvegardes régulièrement

### Workflow Recommandé
1. **Début de session** : Vérifier s'il y a des sauvegardes à restaurer
2. **Pendant le travail** : Laisser faire la sauvegarde automatique
3. **Points critiques** : Sauvegarde manuelle (💾 Sauver)
4. **Fin de session** : La sauvegarde de fermeture se fait automatiquement

### Maintenance
- **Une fois par semaine** : Vérifier et nettoyer les sauvegardes
- **Avant mise à jour navigateur** : Exporter les sauvegardes importantes
- **Changement d'ordinateur** : Pas de migration automatique

## 🎓 Formation et Support

### Pour Débuter
1. **Lisez ce guide** entièrement
2. **Testez avec quelques points** de contrôle simples
3. **Essayez la restauration** pour vous familiariser
4. **Configurez selon vos besoins**

### Ressources Supplémentaires
- **Documentation technique** : `doc/CONTROL_POINTS_BACKUP.md`
- **Tests de l'interface** : `test-backup-system.html`
- **Code source** : `js/control-points-backup.js`

### Support
- **Console JavaScript** (F12) pour diagnostiquer les problèmes
- **Logs détaillés** disponibles pour les développeurs
- **Interface de test** pour valider le fonctionnement

---

## ✅ Checklist de Vérification

Avant de commencer votre travail, vérifiez que :

- [ ] La sauvegarde automatique est activée (paramètres)
- [ ] Les boutons 💾 et 📁 sont visibles dans la barre latérale
- [ ] L'indicateur de statut s'affiche
- [ ] Aucune erreur dans la console JavaScript
- [ ] Les paramètres sont configurés selon vos préférences

**Votre travail est maintenant protégé ! 🛡️**

---

*Cette fonctionnalité améliore significativement la robustesse de Galligeo en éliminant les risques de perte de données lors du géoréférencement. Elle fonctionne de manière totalement transparente et locale, sans impact sur les performances ou la confidentialité.*
