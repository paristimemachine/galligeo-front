# Nouveau Système de Saisie Amélioré - UI/UX

## Vue d'ensemble

Le nouveau système de saisie remplace l'ancien système `drawcontrol` de Leaflet par une interface plus intuitive et plus efficace basée sur les contrôles DSFR (Système de Design de l'État Français).

## Fonctionnalités principales

### 1. Contrôle de verrouillage
- **Toggle Saisie/Verrouillé** : Permet d'activer/désactiver la saisie
- Quand verrouillé : tous les contrôles de saisie sont désactivés
- Quand en mode saisie : les contrôles segmentés deviennent actifs

### 2. Contrôles segmentés
- **segmented-1 (Points)** : Active la saisie de points de contrôle
- **segmented-2 (Emprise)** : Active la saisie de l'emprise (polygone)

### 3. Saisie de points améliorée
- **Numérotation automatique** : Chaque point reçoit un numéro unique
- **Appariement intelligent** : Les points sont automatiquement appariés entre les cartes gauche et droite
- **Alternance automatique** : Le système alterne automatiquement entre les cartes pour réduire le nombre de clics
- **Déplacement interactif** : Survol + glisser-déposer pour déplacer les points existants
- **Validation** : Le géoréférencement n'est possible qu'avec un nombre égal de points sur chaque carte

### 4. Saisie d'emprise optimisée
- **Polygone fermé** : Assure automatiquement la fermeture du polygone
- **Visualisation progressive** : Affichage en temps réel pendant la construction
- **Double-clic pour finaliser** : Possibilité de terminer l'emprise avec un double-clic

## Structure technique

### Variables globales ajoutées
```javascript
let inputMode = 'disabled';        // 'disabled', 'points', 'emprise'
let currentInputMode = 'points';   // 'points' ou 'emprise'
let activeMap = 'left';           // 'left' ou 'right'
let pointCounter = 0;             // Compteur des points
let isInputLocked = false;        // État du verrou
let pointPairs = [];              // Paires de points appariés
let currentPolygon = null;        // Polygone en cours d'édition
```

### Nouvelles structures de données
```javascript
// Structure pour les paires de points
function ControlPointPair(id, leftPoint = null, rightPoint = null) {
    this.id = id;
    this.leftPoint = leftPoint;   // {lat, lng, marker, originalCoords}
    this.rightPoint = rightPoint; // {lat, lng, marker, originalCoords}
    this.isComplete = function() {
        return this.leftPoint !== null && this.rightPoint !== null;
    };
}
```

### Fonctions principales

#### Configuration
- `setupAdvancedInputSystem()` : Initialise le nouveau système
- `setupControlEvents()` : Configure les événements des contrôles
- `setupMapClickEvents()` : Configure les événements de clic sur les cartes

#### Gestion des points
- `handlePointClick(event, mapSide, map, layer)` : Gère la saisie d'un point
- `findOrCreatePointPair()` : Trouve ou crée une paire de points
- `setupMarkerDragEvents(marker, pointPair, mapSide)` : Configure le déplacement des marqueurs

#### Gestion de l'emprise
- `handleEmpriseClick(event, map)` : Gère la saisie d'emprise
- `updatePolygonData()` : Met à jour les données du polygone
- `finalizeEmprise()` : Finalise l'emprise actuelle

#### Interface utilisateur
- `updateInputState()` : Met à jour l'état général du système
- `updateUIForInputMode()` : Met à jour l'interface selon le mode actif
- `updateControlPointsTable()` : Met à jour la table des points de contrôle

#### Utilitaires
- `resetInputSystem()` : Réinitialise complètement le système
- `clearAllControlPoints()` : Supprime tous les points
- `clearEmprise()` : Supprime l'emprise
- `validatePointParity()` : Vérifie l'égalité des points
- `exportGeoreferencingData()` : Exporte les données pour le géoréférencement

## Compatibilité

Le nouveau système maintient la compatibilité avec l'API existante :
- Les variables `list_georef_points` et `list_points_polygon_crop` sont mises à jour automatiquement
- La fonction `click_georef()` continue de fonctionner sans modification
- Le compteur `count_points` est maintenu pour compatibilité

## Interface utilisateur

### Nouveaux éléments HTML
```html
<!-- Statut de saisie -->
<div class="fr-notice fr-notice--info" id="input-status-container">
    <p id="input-status">Système de saisie initialisé</p>
    <div id="input-help" class="input-help-message">Messages d'aide contextuelle</div>
</div>

<!-- Boutons d'action -->
<div class="fr-btns-group" id="input-actions">
    <button id="btn_clear_points" onclick="clearAllControlPoints()">Effacer points</button>
    <button id="btn_clear_emprise" onclick="clearEmprise()">Effacer emprise</button>
</div>
```

### Styles CSS ajoutés
- Indicateurs visuels pour les cartes actives
- Styles pour les tooltips numérotés
- Animations pour le feedback utilisateur
- Styles responsives pour les petits écrans

## Avantages du nouveau système

1. **Meilleure UX** : Interface plus intuitive et guidée
2. **Moins de clics** : Alternance automatique entre les cartes
3. **Feedback visuel** : Indications claires de l'état et des actions possibles
4. **Robustesse** : Validation des données et gestion d'erreurs améliorée
5. **Accessibilité** : Conforme aux standards DSFR
6. **Maintenance** : Code plus modulaire et mieux structuré

## Migration depuis l'ancien système

L'ancien système `drawcontrol` de Leaflet a été complètement remplacé mais :
- Toutes les fonctionnalités existantes sont préservées
- L'API publique reste compatible
- Les données de sortie ont le même format
- Aucune modification requise dans les autres parties de l'application

## Tests

Utilisez le fichier `test-new-input-system.html` pour tester les fonctionnalités :
- Vérification de l'état du système
- Export des données de test
- Réinitialisation du système
- Tests automatiques des fonctions clés
