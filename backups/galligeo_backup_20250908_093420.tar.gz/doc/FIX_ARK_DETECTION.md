# Correction : Détection ARK pour Restauration Automatique

## Problème Identifié

Après tests, il a été constaté que la restauration automatique ne fonctionnait pas car :

1. **Timing incorrect** : `checkForAutoRestore()` était appelé au `DOMContentLoaded` avant que l'ARK soit défini
2. **Variable ARK non accessible** : `input_ark` était défini localement mais `window.input_ark` n'était pas toujours défini
3. **Manque de logging** : Difficile de déboguer sans logs détaillés

## Corrections Apportées

### 1. Déplacement de l'Appel de Vérification

**Fichier modifié** : `js/gallica_interactions.js`

```javascript
// Ajouté à la fin de load_ark_picture()
if (window.controlPointsBackup && input_ark) {
    setTimeout(() => {
        window.controlPointsBackup.checkForAutoRestore();
    }, 500); // Petit délai pour s'assurer que tout est initialisé
}
```

**Pourquoi** : La vérification se fait maintenant APRÈS le chargement de la carte et la définition de l'ARK.

### 2. Synchronisation des Variables ARK

**Fichier modifié** : `js/gallica_interactions.js`

```javascript
// Assurer que window.input_ark est aussi défini pour le système de sauvegarde
window.input_ark = input_ark;
```

**Pourquoi** : S'assurer que le système de sauvegarde peut accéder à l'ARK via `window.input_ark`.

### 3. Amélioration de la Détection ARK

**Fichier modifié** : `js/control-points-backup.js`

```javascript
getCurrentArk() {
    // Essayer d'abord window.input_ark, puis input_ark global
    return window.input_ark || (typeof input_ark !== 'undefined' ? input_ark : null);
}
```

**Pourquoi** : Robustesse en vérifiant les deux sources possibles de l'ARK.

### 4. Logging Détaillé

**Fichier modifié** : `js/control-points-backup.js`

Ajout de logs détaillés dans `checkForAutoRestore()` :
- État de l'ARK détecté
- Valeurs des variables ARK
- Présence de sauvegardes
- Âge des sauvegardes
- Décisions prises

### 5. Suppression de l'Ancien Mécanisme

**Fichier modifié** : `js/control-points-backup.js`

Suppression de :
```javascript
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(async () => {
        await window.controlPointsBackup.checkForAutoRestore();
    }, 2000);
});
```

**Pourquoi** : Ce mécanisme était appelé trop tôt, avant le chargement de l'ARK.

## Flux Corrigé

### Avant (Défaillant)
1. Page chargée → `DOMContentLoaded`
2. 2 secondes d'attente
3. `checkForAutoRestore()` appelé → **ARK pas encore défini** ❌
4. Utilisateur charge une carte → ARK défini
5. **Aucune vérification de restauration** ❌

### Après (Fonctionnel)
1. Page chargée → `DOMContentLoaded`
2. Utilisateur charge une carte → `load_ark_picture()`
3. ARK défini et `window.input_ark` synchronisé
4. 500ms d'attente
5. `checkForAutoRestore()` appelé → **ARK disponible** ✅
6. Sauvegardes vérifiées et proposition de restauration ✅

## Fonctions de Test Ajoutées

### Tests Manuels
```javascript
// Test complet de détection ARK
window.testArkDetection()

// Test forcé de restauration automatique
window.testForceAutoRestore()

// Test rapide après chargement de carte
quickTestArkDetection()
```

### Logs de Debug
Les logs permettent maintenant de suivre :
- 🔍 Démarrage de la vérification
- 🏷️ ARK détecté
- 📊 Détails des variables ARK
- 💾 Présence de sauvegardes
- ⏰ Âge des sauvegardes
- ✅ Décisions de restauration

## Test de Validation

### Scénario de Test
1. **Créer des points** sur une carte avec ARK spécifique
2. **Recharger la page** (F5)
3. **Charger la même carte**
4. **Vérifier** que la restauration automatique est proposée

### Résultat Attendu
```
🔍 Vérification des sauvegardes à restaurer...
🏷️ ARK actuel détecté: btv1b84460142
📊 Détails ARK: { window.input_ark: "btv1b84460142", global input_ark: "btv1b84460142" }
💾 Dernière sauvegarde trouvée: Oui
⏰ Âge de la sauvegarde: 2 minutes
✅ Proposition de restauration automatique
```

## Compatibilité

- ✅ **Rétrocompatible** : Fonctionne avec les sauvegardes existantes
- ✅ **Performance** : Pas d'impact sur la vitesse de chargement
- ✅ **Robuste** : Gestion des cas d'erreur et des variables manquantes
- ✅ **Debug** : Logs détaillés pour le dépannage

## Conclusion

Le problème de restauration automatique est maintenant résolu. Le système :
1. **Attend** que l'ARK soit défini avant de vérifier les sauvegardes
2. **Détecte** correctement l'ARK depuis les variables globales
3. **Propose** la restauration au bon moment (après chargement de carte)
4. **Log** toutes les étapes pour faciliter le dépannage
