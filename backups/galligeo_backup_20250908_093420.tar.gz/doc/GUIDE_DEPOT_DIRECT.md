# Guide d'utilisation : Dépôt direct depuis "Mes cartes"

## 🎯 Objectif
Déposer une carte géoréférencée sur Nakala directement depuis l'interface "Mon Galligeo / Mes cartes".

## 📋 Prérequis
- Être connecté à Galligeo avec votre compte PTM
- Avoir une carte avec le statut "Géoréférencée" dans vos cartes travaillées

## 🔧 Étapes d'utilisation

### 1. Accéder à vos cartes
- Cliquez sur l'icône utilisateur en haut à droite
- Sélectionnez l'onglet "Mes cartes"

### 2. Identifier une carte géoréférencée
- Cherchez une carte avec le tag vert "Géoréférencée"
- Cette carte affichera un bouton "📤 Déposer sur Nakala"

### 3. Lancer le dépôt
- Cliquez sur le bouton "📤 Déposer sur Nakala"
- La modale de dépôt s'ouvre automatiquement

### 4. Vérifier les informations pré-remplies
- **Vos informations** : Nom, prénom, institution (automatique)
- **Métadonnées de la carte** : Titre, créateur, date (depuis Gallica)
- **Entrepôt** : Nakala pré-sélectionné

### 5. Gérer les points de contrôle
#### Si vous avez des points sauvegardés :
✅ Ils sont automatiquement restaurés

#### Si aucun point n'est trouvé :
⚠️ Un message d'avertissement s'affiche
- Des points par défaut sont créés
- Vous pouvez choisir de continuer ou d'annuler
- **Recommandé** : Retourner sur la page de géoréférencement pour sauvegarder vos vrais points

### 6. Finaliser le dépôt
- Vérifiez/ajustez la clé API Nakala si nécessaire
- Cliquez sur "Déposer"
- Le statut de votre carte passe automatiquement à "Déposée"

## ⚠️ Points d'attention

### Authentification
- Vous devez être connecté pour voir le bouton
- En cas de session expirée, reconnectez-vous

### Points de contrôle
- **Idéal** : Avoir des points sauvegardés depuis la page de géoréférencement
- **Fallback** : Points par défaut (à confirmer explicitement)

### Clé API Nakala
- Utilisez votre propre clé API pour vos dépôts
- La clé par défaut est pour les tests uniquement

## 🎉 Résultat
Après un dépôt réussi :
- La carte affiche le statut "Déposée" avec un tag violet
- Un lien "Voir sur Nakala" apparaît
- La carte reste dans votre liste "Mes cartes"

## 🛠 Dépannage

### Le bouton n'apparaît pas
- Vérifiez que vous êtes connecté
- Vérifiez que la carte a le statut "Géoréférencée"

### Erreur d'ouverture de la modale
- Rafraîchissez la page
- Vérifiez votre connexion internet

### Problème avec les points de contrôle
- Retournez sur la page de géoréférencement
- Sauvegardez manuellement vos points (bouton 💾)
- Revenez pour refaire le dépôt

## 📞 Support
En cas de problème, contactez : galligeo@ptm.huma-num.fr
