# Guide de test de l'authentification Galligeo

## Comment tester l'authentification

### 1. Test de connexion

1. Ouvrez la page `ggo.html` dans votre navigateur
2. Cliquez sur le bouton "Se connecter avec ORCID"
3. Vous serez redirigé vers ORCID pour l'authentification
4. Après connexion, vous serez redirigé vers l'application avec un token dans l'URL

### 2. Vérification du token

Après connexion, vous pouvez vérifier que tout fonctionne :

1. Ouvrez la console développeur (F12)
2. Tapez `debugAuth()` pour voir l'état de l'authentification
3. Vous devriez voir :
   - `Token: [votre-jwt-token]`
   - `isLoggedIn: true`
   - `userData: {name: "...", orcid: "...", ...}`

### 3. Test du menu utilisateur

Une fois connecté :
- Le bouton de connexion devrait devenir un menu déroulant avec votre nom
- Cliquer sur le menu devrait afficher vos informations
- Le bouton "Paramètres" devrait rediriger vers `login.html`
- Le bouton "Se déconnecter" devrait vous déconnecter

### 4. Test de la page profil

1. Allez sur `login.html` (soit via le menu, soit directement)
2. Si vous êtes connecté, vous devriez voir vos informations personnelles
3. Si vous n'êtes pas connecté, vous devriez voir un message d'erreur avec un bouton de connexion

### 5. Test du préremplissage

1. Chargez une carte dans Galligeo
2. Ouvrez la modale de dépôt Nakala
3. Les champs nom, prénom et institution devraient être préremplis automatiquement

## Débogage

### Commandes de debug disponibles

```javascript
// Vérifier l'état de l'authentification
debugAuth()

// Revalider l'authentification
checkAuthStatus()

// Se déconnecter
logout()

// Vérifier le localStorage
localStorage.getItem('ptm_auth_token')

// Effacer le token manuellement
localStorage.removeItem('ptm_auth_token')
```

### Problèmes courants

1. **Token manquant après connexion** :
   - Vérifiez que l'URL de redirection est correcte
   - Vérifiez que le token est bien dans l'URL (après le `#token=`)

2. **Token expiré** :
   - Les tokens ont une durée de vie limitée
   - Reconnectez-vous pour obtenir un nouveau token

3. **Erreur CORS** :
   - Vérifiez que le domaine est autorisé dans la configuration de l'API

4. **Données utilisateur manquantes** :
   - Vérifiez que l'API retourne bien les données attendues
   - Utilisez `debugAuth()` pour voir les données reçues

### Structure attendue des données utilisateur

```javascript
{
  "sub": "0000-0000-0000-0000",    // ORCID ID
  "name": "Prénom Nom",            // Nom complet
  "iss": "ptm-auth",               // Issuer
  "aud": "ptm-apps",               // Audience
  "iat": 1234567890,               // Issued at
  "exp": 1234567890                // Expiration
}
```

## Architecture de l'authentification

### Flux d'authentification

1. **Connexion** : `ggo.html` → ORCID → Callback avec token dans URL
2. **Stockage** : Token sauvé dans `localStorage`
3. **Vérification** : Appel API avec token dans header `Authorization: Bearer <token>`
4. **Données** : Récupération des données utilisateur via API
5. **Interface** : Mise à jour du bouton et des formulaires

### Fichiers modifiés

- `js/api_interactions.js` : Logique d'authentification principale
- `js/login_interactions.js` : Logique spécifique à la page profil
- `js/nakala_test_deposit.js` : Intégration avec préremplissage
- `css/main.css` : Styles pour le menu utilisateur
- `ggo.html` : Initialisation de la vérification d'auth
- `login.html` : Chargement du script de profil
