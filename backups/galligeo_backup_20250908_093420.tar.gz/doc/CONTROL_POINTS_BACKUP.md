# Système de Sauvegarde Automatique des Points de Contrôle

## 🎯 Objectif

Permettre aux utilisateurs de **ne jamais perdre leurs points de contrôle** en cas de :
- Fermeture accidentelle de l'onglet
- Rafraîchissement de la page
- Perte de connexion internet
- Coupure réseau temporaire
- Problème technique du navigateur

## ✨ Fonctionnalités

### 🔄 Sauvegarde Automatique
- **Sauvegarde périodique** : Toutes les 30 secondes par défaut (configurable)
- **Sauvegarde sur action** : À chaque modification des points de contrôle
- **Sauvegarde de sécurité** : Lors de la fermeture de page ou changement d'onglet
- **Sauvegarde contextuelle** : Associée à l'ARK en cours de traitement

### 📁 Gestion des Sauvegardes
- **Historique multiple** : Jusqu'à 10 sauvegardes conservées (configurable)
- **Métadonnées complètes** : Horodatage, session, contexte, ARK
- **Interface de restauration** : Sélection visuelle des sauvegardes
- **Suppression automatique** : Les anciennes sauvegardes sont effacées

### 🛠️ Interface Utilisateur
- **Boutons dédiés** : "💾 Sauver" et "📁 Restaurer" dans la barre latérale
- **Indicateurs visuels** : Statut de sauvegarde en temps réel
- **Notifications** : Confirmation des opérations de sauvegarde/restauration
- **Restauration automatique** : Proposition au démarrage si sauvegardes récentes disponibles

## 🔧 Configuration

Les paramètres de sauvegarde sont accessibles dans **Mon Galligeo > Paramètres géoréférencement** :

### Paramètres Disponibles
- **Activer la sauvegarde automatique** : On/Off
- **Fréquence de sauvegarde** : 15s, 30s, 1min, 5min
- **Nombre maximum de sauvegardes** : 1 à 50 sauvegardes

### Paramètres par Défaut
- Sauvegarde automatique : **Activée**
- Fréquence : **30 secondes**
- Maximum de sauvegardes : **10**

## 💾 Stockage Local

### Technologie Utilisée
- **localStorage** du navigateur
- Pas de dépendance réseau
- Fonctionnement en mode déconnecté

### Structure des Données
```json
{
  "timestamp": "2025-09-05T14:30:00.000Z",
  "trigger": "auto|user-action|page-unload|manual",
  "sessionId": "session_1725544200_abc123",
  "data": {
    "pointPairs": [...],
    "polygon": [...],
    "settings": {...},
    "arkId": "btv1b12345",
    "version": "1.0"
  },
  "metadata": {
    "userAgent": "...",
    "url": "...",
    "arkId": "btv1b12345"
  }
}
```

## 🚀 Utilisation

### Sauvegarde Manuelle
1. Saisir des points de contrôle
2. Cliquer sur le bouton **"💾 Sauver"**
3. Confirmation visuelle de la sauvegarde

### Restauration
1. Cliquer sur le bouton **"📁 Restaurer"**
2. Sélectionner la sauvegarde désirée dans la liste
3. Confirmer la restauration
4. Les points sont automatiquement recréés sur les cartes

### Restauration Automatique
- Au chargement de la page, si une sauvegarde récente (< 24h) existe
- Proposition automatique de restauration
- L'utilisateur peut accepter ou refuser

## 🔍 Déclencheurs de Sauvegarde

### Automatique (`auto`)
- Intervalle régulier (paramétrable)
- Transparent pour l'utilisateur

### Action Utilisateur (`user-action`)
- Ajout/suppression de points
- Modification des points existants
- Déplacement par glisser-déposer

### Fermeture de Page (`page-unload`)
- Fermeture de l'onglet
- Rafraîchissement de la page
- Navigation vers une autre page

### Changement d'Onglet (`visibility-change`)
- Passage à un autre onglet
- Minimisation de la fenêtre
- Perte de focus de l'application

### Manuel (`manual`)
- Clic sur le bouton "💾 Sauver"
- Sauvegarde explicite de l'utilisateur

## 🛡️ Sécurité et Fiabilité

### Gestion d'Erreurs
- **Erreurs de localStorage** : Gestion gracieuse, notifications utilisateur
- **Données corrompues** : Validation et récupération
- **Quota dépassé** : Suppression automatique des anciennes sauvegardes

### Session et Contexte
- **ID de session unique** : Évite les conflits entre onglets
- **Contexte ARK** : Association avec la carte en cours
- **Métadonnées** : Informations de débogage et traçabilité

### Compatibilité
- **API existante** : Aucun impact sur le code existant
- **Intégration transparente** : Utilise les événements DOM
- **Fallback gracieux** : Fonctionne même si certains composants ne sont pas disponibles

## 📊 Surveillance et Debug

### Événements JavaScript
```javascript
// Écouter les sauvegardes
document.addEventListener('controlPointsBackupSaved', (event) => {
  console.log('Sauvegarde effectuée:', event.detail.backup);
});

// Écouter les restaurations
document.addEventListener('controlPointsBackupRestored', (event) => {
  console.log('Restauration effectuée:', event.detail.backup);
});

// Statistiques
const stats = window.controlPointsBackup.getBackupStats();
console.log('Statistiques de sauvegarde:', stats);
```

### API Publique
```javascript
// Sauvegarder manuellement
window.controlPointsBackup.saveCurrentState('manual');

// Afficher l'interface de restauration
window.controlPointsBackup.showRestoreInterface();

// Activer/désactiver
window.controlPointsBackup.setEnabled(true/false);

// Obtenir toutes les sauvegardes
const backups = window.controlPointsBackup.getAllBackups();

// Statistiques
const stats = window.controlPointsBackup.getBackupStats();
```

## 🎨 Interface Utilisateur

### Boutons dans la Sidebar
- **💾 Sauver** : Sauvegarde manuelle immédiate
- **📁 Restaurer** : Interface de sélection des sauvegardes

### Indicateurs Visuels
- **Statut de sauvegarde** : "💾 Sauvegardé 14:30:25"
- **État des boutons** : Activé/désactivé selon le contexte
- **Notifications temporaires** : Confirmations d'opérations

### Modale de Restauration
- **Liste des sauvegardes** : Horodatage, nombre de points, contexte
- **Aperçu des données** : Points de contrôle et emprise
- **Actions** : Restaurer ou supprimer les sauvegardes

## 🔄 Workflow Typique

### Scénario Normal
1. **Utilisateur charge une carte Gallica**
2. **Système propose** restauration si sauvegardes disponibles
3. **Utilisateur saisit** des points de contrôle
4. **Sauvegarde automatique** toutes les 30 secondes
5. **Utilisateur continue** son travail en toute sécurité

### Scénario de Récupération
1. **Problème technique** (fermeture accidentelle, etc.)
2. **Utilisateur relance** l'application
3. **Système détecte** une sauvegarde récente
4. **Proposition de restauration** automatique
5. **Restauration** des points en quelques clics

## 🌟 Avantages

### Pour l'Utilisateur
- **Tranquillité d'esprit** : Aucun risque de perte de données
- **Efficacité** : Reprise du travail instantanée
- **Flexibilité** : Contrôle total sur les sauvegardes
- **Transparence** : Fonctionnement automatique et discret

### Pour le Projet
- **Réduction du support** : Moins de demandes de récupération
- **Amélioration UX** : Expérience utilisateur plus fluide
- **Fiabilité** : Système robuste et testé
- **Évolutivité** : Architecture extensible

## 🔮 Extensions Possibles

### Futures Améliorations
- **Synchronisation cloud** : Sauvegarde sur serveur pour utilisateurs connectés
- **Partage de sauvegardes** : Export/import entre utilisateurs
- **Historique détaillé** : Visualisation des modifications
- **Sauvegarde différentielle** : Optimisation de l'espace de stockage
- **Récupération de crash** : Détection et récupération automatique après plantage

### Intégrations
- **API Cartoquete** : Synchronisation avec les favoris
- **Système d'authentification** : Sauvegardes liées au profil utilisateur
- **Analytics** : Statistiques d'utilisation des sauvegardes
- **Monitoring** : Alertes en cas de problèmes de sauvegarde

---

**Note** : Cette fonctionnalité est entièrement côté client et ne nécessite aucune modification serveur. Elle fonctionne en mode déconnecté et améliore significativement la robustesse de l'application pour les utilisateurs.
