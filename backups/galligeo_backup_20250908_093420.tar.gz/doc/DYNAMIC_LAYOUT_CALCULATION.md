# Système de Calcul Dynamique des Hauteurs - Galligeo

## Problématique Résolue

L'interface Galligeo avait des problèmes de débordement sous le footer et de calculs de hauteur fixes qui ne s'adaptaient pas correctement aux différents éléments de l'interface.

## Solution Mise en Place

### Variables CSS Dynamiques

```css
:root {
    --header-height: 120px;  /* Navigation max-height */
    --footer-height: 62px;   /* Footer height + padding (50px + 12px) */
    --content-buffer: 20px;  /* Espace supplémentaire pour voir les bordures */
    --total-reserved: calc(var(--header-height) + var(--footer-height) + var(--content-buffer));
}
```

### Calcul Intelligent des Hauteurs

Au lieu d'utiliser des valeurs fixes comme `calc(100vh - 220px)`, le système utilise maintenant :
- `calc(100vh - var(--total-reserved))` pour tous les conteneurs principaux

### Éléments Concernés

1. **Conteneur principal** (`.main-content-row`)
2. **Conteneurs de cartes** (`#map-container-left`, `#map-container-right`)
3. **Sidebar** (`#sidebar`)

### Avantages

1. **Maintenabiité** : Une seule modification des variables CSS met à jour tout le layout
2. **Visibilité** : Espace tampon de 20px pour voir les bordures des éléments
3. **Cohérence** : Calculs uniformes dans toute l'application
4. **Flexibilité** : Adaptation automatique si les hauteurs d'en-tête ou footer changent

### Bordures Visuelles

- Bordures ajoutées aux conteneurs : `1px solid #e3e3fd`
- Coins arrondis : `border-radius: 4px`
- Espacement inférieur : `margin-bottom: 8px`

## Calcul Détaillé

```
Total réservé = 120px (nav) + 62px (footer) + 20px (buffer) = 202px
Hauteur disponible = 100vh - 202px
```

Cette approche garantit que les cartes et la sidebar s'arrêtent à 20px au-dessus du footer, rendant leurs bordures clairement visibles.

## Date d'Implémentation

5 septembre 2025

## Contexte

Cette amélioration fait suite aux corrections successives du layout Galligeo, notamment :
- Correction du débordement sous le footer
- Optimisation de l'espace navigation
- Amélioration de l'UI/UX du système de saisie des points de contrôle
