# Intégration API PTM - Galligeo

## Vue d'ensemble

L'application Galligeo est maintenant intégrée avec l'API PTM Auth pour :
- **Authentification** automatique via ORCID
- **Sauvegarde cloud** des paramètres utilisateur
- **Synchronisation** entre appareils
- **Profils utilisateur** centralisés

## Architecture

```
Frontend (Galligeo)
    ↓
ptm-auth.js (Couche d'abstraction)
    ↓
API PTM Auth (https://api.ptm.huma-num.fr)
    ↓
Base de données PostgreSQL
```

## Fichiers ajoutés/modifiés

### Nouveaux fichiers
- `js/ptm-auth.js` - Module d'authentification et API
- `test-api-integration.html` - Page de test de l'intégration

### Fichiers modifiés
- `js/settings-manager.js` - Intégration sauvegarde cloud
- `ggo.html` - Ajout scripts et gestion authentification
- `config/settings-form.json` - Configuration enrichie

## Fonctionnalités

### 1. Authentification automatique
```javascript
// Vérification automatique au chargement
const isAuthenticated = await window.ptmAuth.checkAuthStatus();

// Récupération du profil utilisateur
const profile = await window.ptmAuth.getUserProfile();
```

### 2. Sauvegarde des paramètres
```javascript
// Sauvegarde locale + cloud automatique
await window.settingsManager.saveSettings(data);

// Sauvegarde cloud uniquement
await window.galligeoSettingsAPI.saveSettings(settings);
```

### 3. Synchronisation cross-device
- ✅ **Chargement** : Paramètres récupérés du cloud si disponibles
- ✅ **Conflit** : Résolution basée sur timestamp (plus récent gagne)
- ✅ **Fallback** : Utilisation locale si serveur indisponible

### 4. Interface utilisateur adaptative
- **Non connecté** : Bouton "Se connecter avec ORCID"
- **Connecté** : Menu utilisateur avec nom + accès paramètres
- **Notifications** : Informations sur l'état de sauvegarde

## Flux de données

### Premier chargement (utilisateur connecté)
1. Vérification authentification
2. Chargement paramètres serveur
3. Comparaison avec paramètres locaux
4. Application des plus récents
5. Génération du formulaire

### Sauvegarde de paramètres
1. Validation des données
2. Sauvegarde locale (localStorage)
3. Sauvegarde serveur (si connecté)
4. Notification utilisateur
5. Émission événement `settingsUpdated`

### Gestion hors ligne
- **Mode dégradé** : Fonctionnement local si API indisponible
- **Sync différée** : Rattrapage à la prochaine connexion
- **Notifications** : Information claire sur l'état

## Structure des données

### Format serveur (PTM API)
```json
{
  "version": "1.0",
  "settings": {
    "select-algo": "polynomial",
    "select-resample": "bilinear",
    "select-quality": "hd",
    "checkbox-compression": true,
    "checkbox-transparent": false,
    "checkbox-matrice": true,
    "input-scale": 100000
  },
  "last_updated": "2025-07-30T14:30:00Z"
}
```

### Format local (localStorage)
```json
{
  "select-algo": "polynomial",
  "select-resample": "bilinear",
  "select-quality": "hd",
  "checkbox-compression": true,
  "checkbox-transparent": false,
  "checkbox-matrice": true,
  "input-scale": 100000
}
```

## API PTM utilisée

### URL de base
```javascript
const baseUrl = 'https://api.ptm.huma-num.fr';
```

### Endpoints principaux
- `GET /auth/profile` - Profil utilisateur
- `POST /auth/app/galligeo/data` - Sauvegarde paramètres
- `GET /auth/app/galligeo/data` - Chargement paramètres
- `DELETE /auth/app/galligeo/data` - Suppression paramètres

### Authentification
- **Token JWT** automatiquement géré
- **Refresh** transparent en cas d'expiration
- **Redirection** ORCID si non authentifié

## Gestion d'erreurs

### Types d'erreurs gérées
1. **Token expiré** → Redirection ORCID
2. **Serveur indisponible** → Mode local
3. **Données corrompues** → Valeurs par défaut
4. **Conflit sync** → Résolution automatique

### Messages utilisateur
- ✅ **Succès** : "Paramètres sauvegardés avec succès"
- ⚠️ **Warning** : "Sauvegarde locale uniquement (serveur indisponible)"
- ❌ **Erreur** : "Erreur lors de la sauvegarde"

## Tests et débogage

### Page de test
```
http://localhost/galligeo/test-api-integration.html
```

**Fonctionnalités de test :**
- Vérification authentification
- Test sauvegarde/chargement
- Logs en temps réel
- Formulaire interactif

### Console debugging
```javascript
// Forcer la synchronisation
await window.galligeoSettingsAPI.syncSettings();

// Vérifier l'état
console.log(window.ptmAuth.isAuthenticated());
console.log(await window.ptmAuth.getUserProfile());

// Tester API directement
await window.ptmAuth.apiCall('/app/galligeo/data');
```

## Migration et déploiement

### Compatibilité
- ✅ **Rétrocompatible** : Anciens paramètres préservés
- ✅ **Progressive** : Fonctionne avec/sans authentification
- ✅ **Graceful degradation** : Mode local si API indisponible

### Variables d'environnement
```javascript
// Configuration API (ptm-auth.js)
this.baseUrl = 'https://api.ptm.huma-num.fr/auth'; // Production
// this.baseUrl = 'http://localhost:5050/auth';    // Développement local
```

## Sécurité

### Protection des données
- **Token JWT** stocké de manière sécurisée
- **HTTPS** obligatoire en production
- **Validation** côté serveur des données
- **Sanitization** des entrées utilisateur

### Gestion des permissions
- **Données privées** : Accessibles au propriétaire uniquement
- **Isolation** : Données par application séparées
- **Audit** : Logs d'accès côté serveur

## Performance

### Optimisations
- **Cache local** pour réduire les appels API
- **Debounce** sur les sauvegardes automatiques
- **Lazy loading** des données utilisateur
- **Compression** JSON pour les gros datasets

### Métriques surveillées
- Temps de réponse API
- Taux de succès synchronisation
- Utilisation cache local
- Erreurs d'authentification

## Support et maintenance

### Logs utiles
```javascript
// Activer les logs détaillés
localStorage.setItem('debug', 'true');

// Vérifier l'état de l'intégration
console.log('Auth status:', await window.ptmAuth.checkAuthStatus());
console.log('Settings:', window.settingsManager.settings);
```

### Points de contact
- **API PTM** : Équipe infrastructure PTM
- **Frontend** : Équipe développement Galligeo
- **Authentification** : Service ORCID/PTM Auth
