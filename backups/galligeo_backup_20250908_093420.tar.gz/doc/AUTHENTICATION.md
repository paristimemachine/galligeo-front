# Fonctionnalités d'authentification Galligeo

## Vue d'ensemble

Ce document décrit les nouvelles fonctionnalités d'authentification intégrées dans l'application Galligeo qui permettent aux utilisateurs de se connecter via ORCID et de bénéficier d'une expérience personnalisée.

## Fonctionnalités implémentées

### 1. Bouton de connexion dynamique

- **État non connecté** : Affiche un bouton "Se connecter avec ORCID" qui redirige vers l'API d'authentification
- **État connecté** : Affiche un menu déroulant avec le nom de l'utilisateur et des options d'actions

### 2. Menu utilisateur connecté

Quand l'utilisateur est connecté, le bouton se transforme en menu déroulant contenant :
- **Informations utilisateur** : Nom, ORCID, Email
- **Bouton Paramètres** : Redirige vers la page `login.html`
- **Bouton Déconnexion** : Déconnecte l'utilisateur

### 3. Page de profil utilisateur (`login.html`)

La page `login.html` est maintenant dynamique et affiche :
- **Profil utilisateur** : Informations personnelles récupérées via l'API
- **Paramètres de géoréférencement** : Configuration des préférences utilisateur
- **Mes cartes** : Galerie des cartes de l'utilisateur

### 4. Préremplissage automatique des formulaires

Quand un utilisateur connecté ouvre la modale de dépôt sur Nakala :
- Les champs nom, prénom et institution sont automatiquement préremplis
- Les données proviennent des informations du profil utilisateur

### 5. Gestion des états de connexion

- Vérification automatique de l'état de connexion au chargement des pages
- Mise à jour dynamique de l'interface selon l'état d'authentification
- Gestion des redirections appropriées

## Architecture technique

### Fichiers modifiés/créés

1. **`js/api_interactions.js`** - Fonctions d'authentification principales
2. **`js/login_interactions.js`** - Script spécifique pour la page login
3. **`js/nakala_test_deposit.js`** - Intégration avec les données utilisateur
4. **`css/main.css`** - Styles pour le menu utilisateur
5. **`ggo.html`** - Initialisation de la vérification d'authentification
6. **`login.html`** - Chargement du script de profil

### API d'authentification

L'application communique avec l'API d'authentification via les endpoints :
- `GET /auth/data` - Récupère les données de l'utilisateur connecté (nécessite token JWT)
- `GET /auth/login` - Endpoint de connexion avec redirection (retourne token via URL fragment)
- `GET /auth/app/galligeo/data` - Récupère les données spécifiques à Galligeo
- `POST /auth/app/galligeo/data` - Sauvegarde les données spécifiques à Galligeo

### Gestion des tokens JWT

- **Stockage** : Token JWT stocké dans `localStorage` avec la clé `ptm_auth_token`
- **Récupération** : Token récupéré depuis l'URL (fragment #token=...) après connexion
- **Authentification** : Token envoyé dans l'en-tête `Authorization: Bearer <token>`
- **Expiration** : Gestion automatique des tokens expirés avec nettoyage du localStorage

### Fonctions JavaScript principales

- `checkAuthStatus()` - Vérifie l'état de connexion
- `updateLoginButton()` - Met à jour l'interface utilisateur
- `prefillUserFields()` - Prérempli les formulaires
- `logout()` - Déconnecte l'utilisateur
- `redirectToLogin()` - Gère les redirections de connexion

## Configuration

### Variables d'environnement

```javascript
const AUTH_API_BASE = 'https://api.ptm.huma-num.fr/auth';
```

### Données utilisateur attendues

```javascript
{
  "name": "Prénom Nom",
  "orcid": "0000-0000-0000-0000",
  "email": "user@domain.com",
  "institution": "Nom de l'institution"
}
```

## Utilisation

### Pour les développeurs

1. **Vérifier l'authentification** : Appeler `checkAuthStatus()` au chargement de la page
2. **Écouter les événements** : 
   - `userLoggedIn` - Utilisateur connecté
   - `userLoggedOut` - Utilisateur déconnecté
   - `userNotLoggedIn` - Utilisateur non connecté

3. **Préremplir les formulaires** : Appeler `prefillUserFields()` quand nécessaire

### Pour les utilisateurs

1. Cliquer sur "Se connecter avec ORCID" sur la page d'accueil
2. S'authentifier via ORCID
3. Être redirigé vers l'application avec les informations personnalisées
4. Accéder aux fonctionnalités avancées avec préremplissage automatique

## Sécurité

- Utilisation des cookies de session avec `credentials: 'include'`
- Gestion des erreurs d'API appropriée
- Validation côté client des données utilisateur
- Redirections sécurisées avec URLs encodées

## Améliorations futures

1. **Cache des données utilisateur** pour éviter les appels API répétés
2. **Refresh automatique des tokens** d'authentification
3. **Sauvegarde des préférences utilisateur** côté serveur
4. **Intégration avec d'autres services** d'authentification
5. **Gestion des permissions** par rôle utilisateur
