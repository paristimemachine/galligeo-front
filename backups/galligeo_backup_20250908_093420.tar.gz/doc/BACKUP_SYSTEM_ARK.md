# Système de Sauvegarde Lié aux ARK

## Problème Résolu

Avant cette modification, le système de sauvegarde des points de contrôle dans Galligeo avait les problèmes suivants :

1. **Sauvegarde globale** : Toutes les sauvegardes étaient mélangées sans distinction de carte
2. **Restauration inappropriée** : L'application proposait de restaurer des points même quand aucune carte n'était chargée
3. **Confusion utilisateur** : Les points d'une carte A pouvaient être proposés pour la carte B

## Solution Implémentée

### 1. Stockage par ARK

Le système de sauvegarde a été modifié pour organiser les sauvegardes par ARK (identifiant unique de chaque carte Gallica) :

- **Clé de stockage locale** : `galligeo-control-points-backup-ark-{ARK_ID}`
- **Séparation complète** : Chaque ARK a ses propres sauvegardes
- **Conservation totale** : Toutes les sauvegardes de tous les ARK sont conservées localement

### 2. Modifications Principales

#### A. Classe `ControlPointsBackup`

**Nouvelles méthodes :**
- `getCurrentArk()` : Récupère l'ARK actuel depuis `window.input_ark`
- `getArkStorageKey(arkId)` : Génère la clé de stockage pour un ARK
- `getBackupsForArk(arkId)` : Récupère les sauvegardes d'un ARK spécifique
- `saveBackupsForArk(backups, arkId)` : Sauvegarde pour un ARK spécifique
- `deleteBackupByIndex(index)` : Supprime une sauvegarde de l'ARK actuel

**Méthodes modifiées :**
- `saveCurrentState()` : Vérifie qu'un ARK est chargé avant de sauvegarder
- `getLatestBackup()` : Retourne la dernière sauvegarde de l'ARK actuel
- `showRestoreInterface()` : Affiche seulement les sauvegardes de l'ARK actuel
- `checkForAutoRestore()` : Propose la restauration seulement pour l'ARK actuel

#### B. Classe `PTMAuth`

**Méthodes API étendues :**
- `getAppData(appName, arkId)` : Support optionnel de l'ARK
- `saveAppData(appName, data, arkId)` : Inclusion de l'ARK dans les données
- `deleteAppData(appName, arkId)` : Suppression pour un ARK spécifique

#### C. Classe `GalligeoSettingsAPI`

**Intégration ARK :**
- Toutes les méthodes prennent maintenant un paramètre `arkId` optionnel
- Vérification de la présence d'un ARK avant sauvegarde
- Messages d'erreur explicites si aucun ARK n'est spécifié

### 3. Migration Automatique

Un système de migration automatique a été ajouté :

- **`migrateOldBackups()`** : Migre les anciennes sauvegardes vers le nouveau système
- **Exécution automatique** : Lancée au démarrage de l'application
- **Archivage** : Les anciennes données sont archivées, pas supprimées

### 4. Interface Utilisateur

#### Modale de Restauration

- **En-tête informatif** : Affiche l'ARK de la carte actuelle
- **Compteur de sauvegardes** : Montre le nombre de sauvegardes pour cette carte
- **Bouton Supprimer** : Permet de supprimer des sauvegardes individuelles
- **Messages d'erreur explicites** : Informe si aucune carte n'est chargée

#### Comportements

1. **Page principale sans carte** : Aucune proposition de restauration
2. **Chargement d'une carte** : Vérification des sauvegardes pour cette carte uniquement
3. **Changement de carte** : Les sauvegardes précédentes sont conservées mais non proposées

### 5. Stockage Local

#### Structure

```
localStorage:
├── galligeo-control-points-backup-ark-btv1b84460142  # Sauvegardes pour ARK btv1b84460142
├── galligeo-control-points-backup-ark-btv1b12345678  # Sauvegardes pour ARK btv1b12345678
├── galligeo-control-points-backup-arks-list          # Liste des ARK ayant des sauvegardes
└── galligeo-control-points-backup-archived-{timestamp} # Anciennes sauvegardes migrées
```

#### Avantages

- **Performance** : Accès direct aux sauvegardes d'un ARK
- **Scalabilité** : Pas de limite sur le nombre d'ARK différents
- **Maintenance** : Nettoyage possible par ARK
- **Backup** : Conservation de l'historique complet

### 6. API Serveur

Les modifications permettent également la synchronisation serveur par ARK :

- **Paramètres utilisateur** : Sauvegardés par ARK
- **Points de contrôle** : Possibilité future de sauvegarde serveur par ARK
- **Synchronisation** : Multi-appareil avec distinction par carte

## Utilisation

### Pour l'Utilisateur

1. **Chargement d'une carte** : L'ARK est automatiquement détecté
2. **Création de points** : Sauvegarde automatique liée à cette carte
3. **Restauration** : Seules les sauvegardes de cette carte sont proposées
4. **Changement de carte** : Le système s'adapte automatiquement

### Pour le Développeur

```javascript
// Récupérer l'ARK actuel
const ark = window.controlPointsBackup.getCurrentArk();

// Récupérer les sauvegardes d'un ARK spécifique
const backups = window.controlPointsBackup.getBackupsForArk('btv1b84460142');

// Statistiques par ARK
const stats = window.controlPointsBackup.getBackupStatsByArk();

// Migration manuelle (normalement automatique)
window.controlPointsBackup.migrateOldBackups();
```

## Tests

### Scénarios de Test

1. **Page vide** : Aucune proposition de restauration
2. **Première carte** : Création et sauvegarde de points
3. **Deuxième carte** : Pas de proposition des points de la première carte
4. **Retour première carte** : Restauration possible des points précédents
5. **Migration** : Vérification que les anciennes sauvegardes sont bien migrées

### Commandes de Debug

```javascript
// Afficher toutes les sauvegardes par ARK
console.table(window.controlPointsBackup.getBackupStatsByArk());

// Forcer une sauvegarde
window.controlPointsBackup.saveCurrentState('test-manual');

// Afficher l'ARK actuel
console.log('ARK actuel:', window.controlPointsBackup.getCurrentArk());
```

## Compatibilité

- **Rétrocompatible** : Les anciennes sauvegardes sont automatiquement migrées
- **Progressif** : Fonctionne même si l'API serveur n'est pas encore adaptée
- **Fallback** : Retour au mode global si aucun ARK n'est disponible

## Conclusion

Cette modification résout complètement le problème de confusion entre les cartes et améliore significativement l'expérience utilisateur en proposant des sauvegardes contextuelles et pertinentes.
