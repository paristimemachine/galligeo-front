# Gestion des cartes travaillées - Documentation

## Vue d'ensemble

Cette fonctionnalité permet de suivre et d'afficher les cartes que l'utilisateur a commencé à géoréférencer, ainsi que leur statut dans le processus de géoréférencement.

## Structure des données

### Format de stockage
Les cartes travaillées sont stockées dans la structure de données utilisateur sous la clé `rec_ark` :

```json
{
  "galligeo": {
    "rec_ark": [
      {
        "ark": "btv1b532480876",
        "status": "en-cours",
        "firstWorked": "2025-09-07T10:30:00.000Z",
        "lastUpdated": "2025-09-07T11:45:00.000Z",
        "title": "Plan de Paris 1944",
        "creator": "Girard et Barrère",
        "date": "1944"
      }
    ]
  }
}
```

### Statuts disponibles

- **`en-cours`** : L'utilisateur a commencé à créer des points de contrôle
- **`georeferenced`** : La carte a été géoréférencée avec succès
- **`deposee`** : La carte a été déposée sur Nakala (avec DOI disponible)

## Fonctionnalités

### 1. Enregistrement automatique
Quand l'utilisateur crée son premier point de contrôle sur une carte, celle-ci est automatiquement ajoutée à la liste des cartes travaillées avec le statut "en-cours".

### 2. Mise à jour des statuts
- Après un géoréférencement réussi → statut "georeferenced"
- Après un dépôt sur Nakala → statut "deposee" + ajout du DOI

### 3. Affichage dans l'interface
Les cartes travaillées sont affichées dans l'onglet "Mon Galligeo / Mes cartes" avec :
- Vignette de la carte (via API IIIF Gallica)
- Métadonnées (titre, créateur, date)
- Tags colorés selon le statut
- Liens contextuels selon le statut :
  - **En cours** : lien pour continuer le géoréférencement
  - **Géoréférencée** : lien pour voir le résultat
  - **Déposée** : liens vers le géoréférencement et vers Nakala
- Informations de traçabilité (première fois travaillée, dernière modification)

## Intégration technique

### Fichiers modifiés/créés

1. **`js/ptm-auth.js`** : Nouvelles méthodes API
   - `getWorkedMaps()`
   - `updateWorkedMap(arkId, mapData, status)`
   - `updateMapStatus(arkId, status, additionalData)`
   - `removeWorkedMap(arkId)`

2. **`js/worked-maps-manager.js`** : Nouveau gestionnaire (création)
   - Gestion de l'affichage des cartes travaillées
   - Interface similaire au CartoqueteManager
   - Support des 3 statuts avec liens et couleurs appropriés

3. **`index.html`** : Interface utilisateur
   - Nouvelle section "Vos cartes travaillées" dans l'onglet "Mes cartes"
   - Inclusion du nouveau script

4. **`js/advanced-input-system.js`** : Déclenchement automatique
   - Ajout de la logique pour enregistrer la carte au premier point

5. **`js/front_interactions.js`** : Mise à jour des statuts
   - Mise à jour vers "georeferenced" après géoréférencement réussi

6. **`js/nakala_test_deposit.js`** : Finalisation
   - Mise à jour vers "deposee" après dépôt réussi sur Nakala

### Points d'intégration

#### Ajout d'une carte (automatique)
```javascript
// Appelé automatiquement dans handlePointClick()
if (window.pointPairs.length === 1 && window.workedMapsManager && window.input_ark) {
    window.workedMapsManager.addWorkedMap(window.input_ark);
}
```

#### Mise à jour manuelle du statut
```javascript
// Utilisation directe du gestionnaire
await window.workedMapsManager.updateMapStatus(arkId, 'georeferenced');

// Ou via les fonctions utilitaires globales
await window.updateMapStatus(arkId, 'deposee', { doi: '10.34847/nkl.abc123' });
```

## Avantages pour l'utilisateur

1. **Traçabilité** : L'utilisateur peut voir toutes les cartes sur lesquelles il a travaillé
2. **Continuité** : Possibilité de reprendre le travail sur une carte en cours
3. **Suivi du processus** : Visualisation claire de l'état d'avancement de chaque carte
4. **Accès rapide** : Liens directs vers les résultats et les dépôts Nakala
5. **Historique** : Dates de première utilisation et dernière modification

## Exemple d'utilisation

1. L'utilisateur charge une carte avec un ARK Gallica
2. Il crée son premier point de contrôle → la carte est automatiquement ajoutée avec le statut "en-cours"
3. Il termine le géoréférencement → le statut passe automatiquement à "georeferenced"
4. Il dépose le résultat sur Nakala → le statut passe à "deposee" avec le DOI enregistré
5. Dans l'onglet "Mes cartes", il peut voir toutes ses cartes avec leur statut et accéder rapidement aux résultats

## Notes techniques

- La fonctionnalité nécessite que l'utilisateur soit connecté via l'authentification PTM
- Les données sont synchronisées automatiquement avec le serveur PTM
- L'interface s'adapte automatiquement selon que l'utilisateur est connecté ou non
- Compatible avec la structure existante des favoris Cartoquete
- Utilise les mêmes APIs que le système existant (IIIF pour les vignettes, PTM Auth pour les données)
