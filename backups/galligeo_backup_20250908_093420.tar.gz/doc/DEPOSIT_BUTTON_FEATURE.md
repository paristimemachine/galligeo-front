# Fonctionnalité de dépôt direct depuis "Mes cartes"

## Description

Cette fonctionnalité permet aux utilisateurs de déposer directement leurs cartes géoréférencées sur Nakala depuis l'interface "Mon Galligeo / Mes cartes" sans avoir à retourner sur la page de géoréférencement.

## Fonctionnement

### Statuts des cartes et actions disponibles

1. **En cours** (`en-cours`)
   - Affiche un lien "Continuer le géoréférencement"
   - Pas de bouton de dépôt

2. **Géoréférencée** (`georeferenced`) - **NOUVELLE FONCTIONNALITÉ**
   - Affiche un lien "Voir le géoréférencement"
   - **Affiche un bouton "Déposer sur Nakala"** avec icône upload
   - Le bouton ouvre directement la modale de dépôt avec les données pré-remplies

3. **Déposée** (`deposee`)
   - Affiche un lien "Voir le géoréférencement"
   - Affiche un lien "Voir sur Nakala" (si DOI disponible)
   - Pas de bouton de dépôt

### Flux de dépôt

1. **Clic sur "Déposer sur Nakala"**
   - Vérification de l'authentification utilisateur
   - Chargement des métadonnées de la carte depuis Gallica
   - Tentative de récupération des points de contrôle sauvegardés
   - Pré-remplissage des informations utilisateur (nom, prénom, institution)
   - Ouverture de la modale de dépôt

2. **Gestion des points de contrôle**
   - Recherche des points de contrôle en mémoire
   - Si non trouvés, tentative de restauration depuis les sauvegardes
   - Si toujours non trouvés, création de points par défaut avec avertissement utilisateur
   - Demande de confirmation pour continuer avec des points par défaut

3. **Pré-remplissage des données**
   - **Métadonnées de la carte** : Titre, Créateur, Date, Cote, URL Gallica
   - **Informations utilisateur** : Nom, Prénom, Institution (depuis le profil PTM Auth)
   - **Points de contrôle** : Restaurés depuis la sauvegarde ou créés par défaut

### Améliorations techniques

#### Nouveau CSS
```css
/* Bouton de dépôt dans les cartes */
.fr-card .fr-btn--deposit {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    margin: 0.5rem 0;
}
```

#### Nouvelles méthodes dans WorkedMapsManager

1. **`openDepositModalForMap(arkId)`**
   - Point d'entrée principal pour le dépôt
   - Vérifications de sécurité et d'authentification
   - Orchestration du processus de dépôt

2. **`prefillUserDataInModal()`**
   - Récupère et pré-remplit les données utilisateur
   - Gère la division nom/prénom automatique

3. **`loadMapForDeposit(arkId)`**
   - Charge les métadonnées Gallica
   - Gère les points de contrôle (récupération/création)
   - Définit les variables globales nécessaires

4. **`tryRestoreControlPoints(arkId)`**
   - Tente de restaurer les points de contrôle sauvegardés
   - Integration avec le système de sauvegarde existant

5. **`createDefaultControlPoints(arkId)`**
   - Fallback pour créer des points par défaut
   - Points centrés sur Paris (fallback générique)

## Sécurité et validations

- **Authentification requise** : Vérification obligatoire avant ouverture de la modale
- **Validation des données** : Vérification de la présence des métadonnées
- **Confirmation utilisateur** : Demande de confirmation si utilisation de points par défaut
- **Gestion d'erreurs** : Messages d'erreur explicites et récupération gracieuse

## Interface utilisateur

### Bouton de dépôt
- **Style** : Bouton secondaire avec icône upload
- **Placement** : Dans la section de liens de chaque carte géoréférencée
- **Tooltip** : "Déposer cette carte géoréférencée sur Nakala"

### Messages utilisateur
- **Information** : Pré-remplissage automatique confirmé
- **Avertissement** : Points de contrôle par défaut utilisés
- **Erreur** : Problèmes de connexion ou de chargement

## Tests disponibles

Un fichier de test `test-deposit-button.js` est fourni avec :

- `testDepositButton()` : Vérifie la génération correcte du HTML
- `testDepositModal()` : Teste l'ouverture et le chargement de la modale
- `testCardStatusRendering()` : Vérifie l'affichage selon les différents statuts
- `runAllDepositTests()` : Lance tous les tests

### Utilisation des tests
```javascript
// Dans la console du navigateur
runAllDepositTests();
```

## Intégration avec l'existant

- **Compatible** avec le système de dépôt existant (`deposerSurNakala`)
- **Réutilise** la modale de dépôt existante
- **S'appuie** sur le système d'authentification PTM Auth
- **Intègre** le système de sauvegarde des points de contrôle
- **Met à jour** automatiquement le statut de la carte après dépôt réussi

## Variables globales utilisées

- `window.input_ark` : ARK de la carte courante pour le dépôt
- `window.metadataDict` : Métadonnées de la carte pour le dépôt
- `window.pointPairs` : Points de contrôle pour le dépôt
- `window.ptmAuth` : Service d'authentification
- `window.workedMapsManager` : Gestionnaire des cartes travaillées
- `window.controlPointsBackup` : Système de sauvegarde des points

## Fichiers modifiés

1. **`js/worked-maps-manager.js`** : Nouvelles méthodes et logique de dépôt
2. **`css/main.css`** : Styles pour le bouton de dépôt
3. **`index.html`** : Ajout du script de test
4. **`js/test-deposit-button.js`** : Nouveau fichier de tests

Cette fonctionnalité améliore significativement l'expérience utilisateur en permettant un dépôt direct depuis l'interface de gestion des cartes, tout en maintenant la robustesse et la sécurité du système existant.
