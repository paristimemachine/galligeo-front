# Test de données Cartoquete

Pour tester les favoris Cartoquete, vous pouvez utiliser ces données d'exemple à injecter via l'API PTM Auth :

## Structure de données Cartoquete

```json
{
  "cartoquete": {
    "favoris": [
      {
        "ark": "btv1b53136010w",
        "source": "Gallica"
      },
      {
        "ark": "btv1b5901081d",
        "source": "Gallica"
      },
      {
        "ark": "btv1b531359836",
        "source": "Gallica"
      },
      {
        "ark": "btv1b8441346h",
        "source": "Gallica"
      },
      {
        "ark": "btv1b532480876",
        "source": "Gallica"
      }
    ]
  }
}
```

## ARKs de test avec métadonnées disponibles

- `btv1b53136010w` : Carte de France
- `btv1b5901081d` : Plan de ville
- `btv1b531359836` : Carte géographique
- `btv1b8441346h` : Plan de la ville d'Amiens en 1848
- `btv1b532480876` : Carte des fils télégraphiques

## Comment tester

1. **Authentification** : Se connecter avec ORCID via PTM Auth
2. **Injection des données** : Utiliser l'API PTM Auth pour enregistrer les données Cartoquete
3. **Vérification** : Recharger Galligeo et vérifier l'onglet "Mes cartes"

## URLs de test

- Page de test complète : `/test-cartoquete-favorites.html`
- Application principale : `/ggo.html`

## API Endpoints

- GET `/app/cartoquete/data` : Récupérer les données Cartoquete
- POST `/app/cartoquete/data` : Sauvegarder les données Cartoquete

## Métadonnées Gallica

Les métadonnées sont récupérées automatiquement via :
```
https://gallica.bnf.fr/iiif/ark:/12148/{arkId}/manifest.json
```

Les vignettes sont générées via :
```
https://gallica.bnf.fr/iiif/ark:/12148/{arkId}/f1/full/300,/0/native.jpg
```
