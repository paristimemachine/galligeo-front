# Système de gestion des options non disponibles

## Description

Ce système permet de marquer certaines options dans les formulaires de configuration comme "non disponibles" ou "en cours de développement", tout en les affichant dans l'interface utilisateur avec un styling approprié.

## Configuration

### Structure JSON

Dans le fichier `config/settings-form.json`, chaque option peut maintenant inclure une propriété `available` :

```json
{
  "value": "option_value",
  "label": "Nom de l'option",
  "description": "Description de l'option",
  "available": true|false
}
```

### Exemples

#### Options d'algorithmes de géoréférencement
```json
"options": [
  { "value": "polynomial", "label": "Polynomial", "description": "...", "available": true },
  { "value": "helmert", "label": "Helmert", "description": "...", "available": true },
  { "value": "affine", "label": "Affine", "description": "...", "available": false },
  { "value": "tps", "label": "Thin Plate Spline", "description": "...", "available": false }
]
```

#### Options de rééchantillonage
```json
"options": [
  { "value": "nearest", "label": "Plus proche voisin", "description": "...", "available": true },
  { "value": "bilinear", "label": "Bilinéaire", "description": "...", "available": true },
  { "value": "cubic", "label": "Cubique", "description": "...", "available": false },
  { "value": "lanczos", "label": "Lanczos", "description": "...", "available": false }
]
```

## Comportement dans l'interface

### Options non disponibles (`available: false`)
- Affichées avec le texte "(bientôt disponible)" ajouté au label
- Désactivées (non sélectionnables)
- Stylées en gris italique
- Tooltip modifié avec mention "Non disponible actuellement"

### Options disponibles (`available: true` ou propriété absente)
- Comportement normal
- Sélectionnables
- Style standard

### Message d'information
Si un champ select contient au moins une option non disponible, un message informatif est affiché sous le champ : "Certaines options sont en cours de développement."

## Fichiers modifiés

1. **`config/settings-form.json`** : Ajout de la propriété `available` aux options
2. **`js/form-generator.js`** : Logique de génération des options avec gestion du statut
3. **`css/main.css`** : Styles pour les options non disponibles

## CSS appliqué

```css
/* Options désactivées */
.fr-select option:disabled {
  color: #999 !important;
  font-style: italic !important;
  background-color: #f5f5f5 !important;
}

/* Message d'information */
.form-field-unavailable-notice {
  font-size: 0.8em;
  color: #666;
  font-style: italic;
  margin-top: 4px;
  display: flex;
  align-items: center;
  gap: 4px;
}
```

## Activation/Désactivation d'options

Pour activer une option précédemment non disponible :
1. Changer `"available": false` en `"available": true` dans `settings-form.json`
2. Implémenter la fonctionnalité côté backend
3. Tester le bon fonctionnement

## Avantages

- **UX améliorée** : Les utilisateurs voient toutes les options futures
- **Transparence** : Communication claire sur les développements en cours
- **Maintenabilité** : Facile d'activer/désactiver des options
- **Accessibilité** : Tooltips informatifs et styles appropriés
