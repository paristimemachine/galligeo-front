# Configuration des paramètres de sauvegarde automatique

## Fréquences disponibles

Les fréquences de sauvegarde automatique sont configurées dans `config/settings-form.json` :

```json
"options": [
  { "value": "120", "label": "2 minutes", "description": "Recommandé - équilibre optimal" },
  { "value": "300", "label": "5 minutes", "description": "Sauvegarde espacée" },
  { "value": "600", "label": "10 minutes", "description": "Sauvegarde très espacée" }
]
```

## Valeurs par défaut

- **Sauvegarde automatique** : Activée
- **Fréquence** : 120 secondes (2 minutes)
- **Nombre maximum de sauvegardes** : 10

## Protection et validation

### Filtrage côté client
Le `FormGenerator` filtre automatiquement les options de fréquence non autorisées (< 120 secondes).

### Validation côté serveur
Le système applique automatiquement un minimum de 120 secondes si une valeur inférieure est fournie.

### Anti-cache
Les fichiers de configuration JSON utilisent un timestamp pour éviter les problèmes de mise en cache navigateur.

## Fichiers modifiés

- `config/settings-form.json` : Configuration des options
- `js/form-generator.js` : Filtrage et anti-cache
- `js/control-points-backup.js` : Validation et protection
- `.htaccess` : En-têtes anti-cache pour les JSON

---

*Dernière mise à jour : 7 septembre 2025*
