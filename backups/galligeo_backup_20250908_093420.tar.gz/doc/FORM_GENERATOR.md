# Générateur de Formulaire Dynamique

Ce système permet de créer dynamiquement des formulaires à partir de configurations JSON, rendant l'ajout de nouveaux paramètres très simple et maintenable.

## Structure des fichiers

```
config/
  └── settings-form.json     # Configuration du formulaire
js/
  ├── form-generator.js      # Générateur de formulaire
  └── settings-manager.js    # Gestionnaire des paramètres
examples/
  └── modal-integration-example.html  # Exemple d'intégration
```

## Utilisation

### 1. Inclure les scripts dans votre HTML

```html
<script src="js/form-generator.js"></script>
<script src="js/settings-manager.js"></script>
```

### 2. Initialiser le formulaire

```javascript
// Initialisation simple
await window.settingsManager.init('settings-form-container');

// Ou avec gestion d'erreur
try {
    await window.settingsManager.init('settings-form-container');
} catch (error) {
    console.error('Erreur:', error);
}
```

### 3. Écouter les changements de paramètres

```javascript
document.addEventListener('settingsUpdated', function(event) {
    const settings = event.detail.settings;
    // Appliquer les nouveaux paramètres
});
```

## Configuration JSON

### Structure de base

```json
{
  "fields": [
    // Définition des champs
  ],
  "submitButton": {
    "text": "Enregistrer",
    "classes": "fr-btn fr-mt-3w"
  }
}
```

### Types de champs supportés

#### Select
```json
{
  "type": "select",
  "id": "mon-select",
  "name": "mon-select",
  "label": "Mon libellé",
  "placeholder": "Choisir une option",
  "required": false,
  "options": [
    { "value": "option1", "label": "Option 1" },
    { "value": "option2", "label": "Option 2" }
  ]
}
```

#### Checkbox
```json
{
  "type": "checkbox",
  "id": "ma-checkbox",
  "name": "ma-checkbox",
  "label": "Mon libellé",
  "hint": "Texte d'aide optionnel",
  "required": false
}
```

#### Input (text, number, email, password)
```json
{
  "type": "number",
  "id": "mon-input",
  "name": "mon-input",
  "label": "Mon libellé",
  "placeholder": "Valeur exemple",
  "hint": "Texte d'aide optionnel",
  "required": true
}
```

## API du SettingsManager

### Méthodes principales

- `init(containerId)` : Initialise le formulaire
- `getSetting(key, defaultValue)` : Récupère un paramètre
- `setSetting(key, value)` : Définit un paramètre
- `saveSettings(data)` : Sauvegarde les paramètres
- `loadSettings()` : Charge les paramètres
- `resetSettings()` : Remet à zéro
- `exportSettings()` : Exporte en JSON
- `importSettings(file)` : Importe depuis un fichier

### Événements

- `settingsUpdated` : Émis quand les paramètres changent

## Ajouter de nouveaux paramètres

Pour ajouter un nouveau paramètre, il suffit de modifier le fichier `config/settings-form.json` :

```json
{
  "fields": [
    // ... champs existants ...
    {
      "type": "select",
      "id": "nouveau-parametre",
      "name": "nouveau-parametre",
      "label": "Mon nouveau paramètre",
      "placeholder": "Sélectionner...",
      "options": [
        { "value": "valeur1", "label": "Valeur 1" },
        { "value": "valeur2", "label": "Valeur 2" }
      ]
    }
  ]
}
```

Le champ apparaîtra automatiquement dans le formulaire au prochain chargement.

## Personnalisation

### Styles CSS

Les classes CSS utilisées suivent la convention DSFR :
- `.fr-select-group` pour les selects
- `.fr-checkbox-group` pour les checkboxes  
- `.fr-input-group` pour les inputs
- `.fr-btn` pour les boutons

### Validation personnalisée

Pour ajouter une validation personnalisée :

```javascript
window.settingsManager.formGenerator.onSubmit((data, event) => {
    // Validation personnalisée
    if (!data['mon-champ-requis']) {
        alert('Ce champ est requis');
        return false;
    }
    
    // Sauvegarder si tout est OK
    window.settingsManager.saveSettings(data);
});
```

### Stockage personnalisé

Par défaut, les paramètres sont stockés dans le localStorage. Pour utiliser un autre système :

```javascript
class CustomSettingsManager extends SettingsManager {
    saveSettings(data) {
        // Votre logique de sauvegarde personnalisée
        // Par exemple, envoyer à un serveur
        fetch('/api/settings', {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }
    
    loadSettings() {
        // Votre logique de chargement personnalisée
        return fetch('/api/settings').then(r => r.json());
    }
}
```

## Bonnes pratiques

1. **Noms des champs** : Utilisez des noms explicites et cohérents
2. **Validation** : Ajoutez des hints pour guider l'utilisateur
3. **Valeurs par défaut** : Définissez des valeurs par défaut sensées
4. **Groupement** : Organisez les champs par catégories si nécessaire
5. **Documentation** : Documentez chaque paramètre dans le code

## Extensibilité

Le système est conçu pour être facilement extensible :

- Nouveaux types de champs : Ajoutez des méthodes `generateXxxField()` dans FormGenerator
- Nouvelle validation : Étendez les méthodes de SettingsManager
- Nouveau stockage : Héritez de SettingsManager et redéfinissez les méthodes de persistance
