# Optimisations de l'autosave - Système de sauvegarde automatique

## Problèmes résolus

### 1. Sauvegarde trop fréquente
**Problème :** L'autosave se déclenchait toutes les 30 secondes, même sans changements.

**Solution :**
- Temps de base augmenté de **30 secondes à 2 minutes** par défaut
- Minimum de 2 minutes imposé dans le code pour éviter les configurations trop agressives
- Options de configuration : 2 min (recommandé), 5 min, 10 min, 1 min (déconseillé)

### 2. Sauvegarde sans changements
**Problème :** Le système sauvegardait même quand aucun changement n'avait été fait.

**Solution :**
- Nouveau flag `hasUnsavedChanges` pour tracker les modifications
- La méthode `saveCurrentStateIfChanged()` vérifie ce flag avant de sauvegarder
- Les actions utilisateur marquent automatiquement les changements via `markUnsavedChanges()`

### 3. Sauvegardes en doublon
**Problème :** Des sauvegardes identiques étaient créées.

**Solution :**
- Calcul d'un hash de l'état actuel avec `calculateStateHash()`
- Comparaison avec `lastSavedStateHash` pour détecter les doublons
- Sauvegarde uniquement si l'état a vraiment changé

## Modifications techniques

### Fichiers modifiés

1. **`js/control-points-backup.js`**
   - Nouvelles propriétés : `lastSavedStateHash`, `hasUnsavedChanges`
   - Nouvelles méthodes : `saveCurrentStateIfChanged()`, `calculateStateHash()`, `markUnsavedChanges()`
   - Temps d'autosave par défaut : 120000ms (2 minutes)
   - Délai de debounce augmenté à 2 secondes

2. **`js/advanced-input-system.js`**
   - Remplacement de `saveCurrentState()` par `saveCurrentStateIfChanged()`
   - Ajout d'appels à `markUnsavedChanges()` avant les sauvegardes
   - Marquage des changements lors de l'ajout de nouveaux points

3. **`config/settings-form.json`**
   - Nouvelle valeur par défaut : 120 secondes (2 minutes)
   - Nouvelles options de fréquence plus appropriées
   - Mise à jour des descriptions pour décourager les sauvegardes trop fréquentes

### Nouvelles méthodes

#### `saveCurrentStateIfChanged(trigger = 'auto')`
- Vérifie `hasUnsavedChanges` pour les sauvegardes automatiques
- Calcule un hash de l'état actuel
- Compare avec la dernière sauvegarde
- Sauvegarde uniquement si nécessaire

#### `calculateStateHash(state)`
- Crée une représentation simplifiée de l'état
- Calcule un hash pour détecter les changements
- Ignore les propriétés non-critiques (markers, etc.)

#### `markUnsavedChanges()`
- Marque qu'il y a des modifications non sauvegardées
- Appelé automatiquement lors des actions utilisateur

## Fonctions de test

Nouvelles fonctions disponibles en console pour tester :

```javascript
// Teste les optimisations d'autosave
testAutosaveOptimizations()

// Vérifie l'état actuel et les changements
testStateChange()
```

## Comportement attendu

### Avant les optimisations
- ❌ Sauvegarde toutes les 30 secondes systématiquement
- ❌ Sauvegardes même sans changements
- ❌ Création de doublons identiques
- ❌ Nombreuses sauvegardes inutiles

### Après les optimisations
- ✅ Sauvegarde toutes les 2 minutes minimum
- ✅ Sauvegarde uniquement s'il y a des changements non sauvegardés
- ✅ Évite les doublons grâce à la comparaison de hash
- ✅ Sauvegardes plus intelligentes et moins fréquentes

## Cas d'utilisation

1. **Utilisateur inactif** : Aucune sauvegarde automatique
2. **Ajout de points** : Marquage de changements + sauvegarde après délai
3. **Déplacement de points** : Idem
4. **Modifications identiques répétées** : Une seule sauvegarde
5. **Fermeture de page** : Sauvegarde forcée si changements non sauvegardés

## Configuration recommandée

- **Fréquence autosave** : 2 minutes (par défaut)
- **Nombre max de sauvegardes** : 10 (par défaut)
- **Délai de debounce** : 2 secondes

## Journalisation améliorée

Les logs indiquent maintenant :
- Quand une sauvegarde est sautée (pas de changements)
- Quand un doublon est détecté
- La fréquence configurée au démarrage
- Le nombre de points/emprise sauvegardés

## Tests

Pour tester les optimisations :

1. Ouvrir la console navigateur
2. Exécuter `testAutosaveOptimizations()`
3. Observer les logs pour vérifier le comportement
4. Utiliser `testStateChange()` pour vérifier la détection de changements
