# Chargement automatique des paramètres utilisateur

## Vue d'ensemble

Le système Galligeo charge automatiquement les paramètres utilisateur depuis le serveur PTM Auth lorsqu'un utilisateur se connecte avec son compte ORCID. Cette fonctionnalité permet une expérience utilisateur transparente où les préférences sont synchronisées entre les sessions et les appareils.

## Flux d'authentification et chargement des paramètres

### 1. Connexion utilisateur

Quand un utilisateur clique sur "Se connecter avec ORCID" :

1. Redirection vers `https://api.ptm.huma-num.fr/auth/login`
2. Authentification ORCID
3. Retour sur Galligeo avec un token JWT dans l'URL
4. Le token est automatiquement détecté et sauvegardé
5. **Chargement automatique des paramètres utilisateur**

### 2. Détection du token et chargement automatique

```javascript
// Dans ggo.html - DOMContentLoaded
const urlParams = new URLSearchParams(window.location.search);
const token = urlParams.get('token') || urlParams.get('access_token');

if (token) {
    console.log('Token détecté, configuration auth...');
    window.ptmAuth.setToken(token);
    
    // Nettoyer l'URL
    window.history.replaceState({}, document.title, window.location.pathname);
    
    // Charger automatiquement les paramètres
    await window.settingsManager.reloadSettingsAfterLogin();
}
```

### 3. Chargement des paramètres depuis le serveur

```javascript
// Dans SettingsManager.reloadSettingsAfterLogin()
const cloudSettings = await window.ptmAuth.getGalligeoSettings();

if (cloudSettings) {
    // Fusion avec les paramètres locaux
    const currentSettings = this.loadLocalSettings();
    const mergedSettings = { ...currentSettings, ...cloudSettings };
    
    // Application des nouveaux paramètres
    this.settings = mergedSettings;
    this.saveLocalSettings(this.settings);
    
    // Mise à jour du formulaire si ouvert
    if (this.formGenerator && this.formGenerator.config) {
        this.formGenerator.populateForm(this.settings);
    }
}
```

## API utilisée

### Chargement des paramètres

```javascript
// PTMAuth.getGalligeoSettings()
async getGalligeoSettings() {
    try {
        const data = await this.getAppData('galligeo');
        return data?.settings || null;
    } catch (error) {
        console.error('Erreur lors de la récupération des paramètres Galligeo:', error);
        return null;
    }
}
```

**Endpoint:** `GET /app/galligeo/data`

### Sauvegarde des paramètres

```javascript
// PTMAuth.saveGalligeoSettings()
async saveGalligeoSettings(settings) {
    try {
        const data = {
            settings: settings,
            lastUpdated: new Date().toISOString()
        };
        return await this.saveAppData('galligeo', data);
    } catch (error) {
        console.error('Erreur lors de la sauvegarde des paramètres Galligeo:', error);
        throw error;
    }
}
```

**Endpoint:** `POST /app/galligeo/data`

## Structure des données stockées

```json
{
    "settings": {
        "select-algo": "polynomial",
        "select-resample": "cubic", 
        "select-quality": "highres",
        "checkbox-compression": true,
        "checkbox-transparent": false,
        "checkbox-matrice": true,
        "input-scale": 15
    },
    "lastUpdated": "2025-07-30T10:30:00.000Z"
}
```

## Événements système

Le système émet plusieurs événements personnalisés pour notifier l'application :

### settingsLoaded

Émis quand les paramètres sont chargés (au démarrage ou après connexion) :

```javascript
document.addEventListener('settingsLoaded', function(event) {
    const { settings, source } = event.detail;
    // source peut être: 'cloud', 'cloud-reconnect', 'local', 'default', 'error'
    console.log(`Paramètres chargés depuis ${source}:`, settings);
});
```

### settingsUpdated

Émis quand les paramètres sont modifiés par l'utilisateur :

```javascript
document.addEventListener('settingsUpdated', function(event) {
    const { settings } = event.detail;
    console.log('Paramètres mis à jour:', settings);
    
    // Appliquer les nouveaux paramètres dans l'application
    applySettingsToApplication(settings);
});
```

## Stratégie de fallback

Le système utilise une approche en cascade pour charger les paramètres :

1. **Paramètres cloud** (si utilisateur connecté)
2. **Paramètres locaux** (localStorage)
3. **Valeurs par défaut** (depuis la configuration JSON)

```javascript
// Ordre de priorité
if (cloudSettings && userIsAuthenticated) {
    useCloudSettings();
} else if (localSettings && localSettings.length > 0) {
    useLocalSettings();
} else {
    useDefaultSettings();
}
```

## Gestion des conflits

En cas de conflit entre paramètres locaux et serveur, la stratégie actuelle privilégie le serveur :

```javascript
// Fusion privilégiant le serveur
const mergedSettings = { ...currentLocalSettings, ...cloudSettings };
```

## Notifications utilisateur

Le système affiche des notifications pour informer l'utilisateur :

- ✅ "Paramètres synchronisés avec le serveur"
- ⚠️ "Paramètres sauvegardés localement (erreur serveur)"
- ℹ️ "Paramètres utilisateur non trouvés sur le serveur"
- ❌ "Erreur lors de la synchronisation"

## Test et débogage

Utilisez la page `test-settings-autoload.html` pour tester le système :

1. **Test d'authentification** : Vérifier la connexion ORCID
2. **Test de chargement** : Simuler le chargement des paramètres
3. **Test de sauvegarde** : Vérifier la synchronisation serveur
4. **Logs détaillés** : Suivre le flux complet d'événements

## Intégration dans l'application

Pour utiliser les paramètres chargés dans votre logique applicative :

```javascript
// Récupérer un paramètre spécifique
const algorithm = window.getAppSetting('select-algo', 'polynomial');
const quality = window.getAppSetting('select-quality', 'native');

// Écouter les changements de paramètres
document.addEventListener('settingsUpdated', function(event) {
    const settings = event.detail.settings;
    
    // Appliquer l'algorithme de géoréférencement
    if (settings['select-algo']) {
        setGeoreferencingAlgorithm(settings['select-algo']);
    }
    
    // Appliquer la qualité d'image
    if (settings['select-quality']) {
        setImageQuality(settings['select-quality']);
    }
});
```

## Sécurité

- Les paramètres sont stockés de manière sécurisée via l'API PTM Auth
- L'accès nécessite une authentification JWT valide
- Les tokens sont automatiquement nettoyés de l'URL après utilisation
- Fallback sur le stockage local en cas d'erreur serveur

## Prochaines améliorations

1. **Résolution de conflits** : Interface pour gérer les conflits entre local/serveur
2. **Historique des paramètres** : Versioning des configurations
3. **Paramètres partagés** : Partage de configurations entre utilisateurs
4. **Import/Export avancé** : Formats multiples, présets
